"""
Sistema de Logging Estructurado en Formato JSON.
Permite observabilidad completa y trazabilidad de eventos sin fallos silenciosos.
"""

import json
import logging
import sys
from datetime import datetime, timezone


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "line": record.lineno
        }

        # Incluir datos extras si se pasaron en el contexto
        if hasattr(record, "device_id"):
            log_entry["device_id"] = getattr(record, "device_id")
        if hasattr(record, "context"):
            log_entry["context"] = getattr(record, "context")
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_entry, ensure_ascii=False)


def setup_logger(name: str = "iot_logistics") -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JSONFormatter())
        logger.addHandler(handler)

    return logger


logger = setup_logger()
