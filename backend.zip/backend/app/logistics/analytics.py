"""
Módulo de Métricas y Analítica Logística Semanal.
Cálculo de Tasa de Rotación (ITR), Incidentes de Stockout y Nivel de Servicio (Fill Rate).
"""

from typing import List, Dict, Any
from datetime import datetime, timezone


class LogisticsAnalytics:
    """
    Motor analítico para seguimiento de KPIs de almacén y desempeño de la cadena de suministro.
    """

    @staticmethod
    def calculate_turnover_ratio(cogs: float, average_inventory_value: float) -> float:
        """
        Calcula el Índice de Rotación de Inventario (Inventory Turnover Ratio - ITR):
        ITR = Cost of Goods Sold (COGS) / Average Inventory Value
        """
        if average_inventory_value <= 0:
            return 0.0
        return round(cogs / average_inventory_value, 2)

    @staticmethod
    def calculate_days_sales_of_inventory(turnover_ratio: float) -> float:
        """
        Calcula los Días de Venta de Inventario (DSI):
        DSI = 365 / ITR
        """
        if turnover_ratio <= 0:
            return 999.0
        return round(365.0 / turnover_ratio, 1)

    @staticmethod
    def calculate_fill_rate(total_demanded: int, total_delivered: int) -> float:
        """
        Calcula la tasa de cumplimiento del pedido (Fill Rate):
        Fill Rate = (Entregado / Demandado) * 100%
        """
        if total_demanded <= 0:
            return 100.0
        return round(min(100.0, (total_delivered / total_demanded) * 100.0), 2)

    @classmethod
    def generate_weekly_summary(
        cls,
        cogs_week: float,
        avg_inventory_value: float,
        stockout_events: List[Dict[str, Any]],
        total_demand_units: int,
        fulfilled_units: int
    ) -> Dict[str, Any]:
        """
        Genera el informe ejecutivo semanal consolidando rotación e incidentes de desabasto.
        """
        itr = cls.calculate_turnover_ratio(cogs_week * 52, avg_inventory_value)
        dsi = cls.calculate_days_sales_of_inventory(itr)
        fill_rate = cls.calculate_fill_rate(total_demand_units, fulfilled_units)

        stockout_count = len(stockout_events)
        total_stockout_duration_hours = sum(e.get("duration_hours", 0.0) for e in stockout_events)
        total_backlog_impact = sum(e.get("unfulfilled_units", 0) for e in stockout_events)

        status_flag = "HEALTHY"
        if stockout_count > 2 or fill_rate < 95.0:
            status_flag = "CRITICAL_ACTION_REQUIRED"
        elif stockout_count > 0 or fill_rate < 98.0:
            status_flag = "ATTENTION_NEEDED"

        return {
            "report_timestamp": datetime.now(timezone.utc).isoformat(),
            "status": status_flag,
            "kpis": {
                "inventory_turnover_annualized": itr,
                "days_sales_of_inventory": dsi,
                "fill_rate_percentage": fill_rate,
                "total_demand_units": total_demand_units,
                "fulfilled_units": fulfilled_units
            },
            "stockout_analysis": {
                "total_incidents": stockout_count,
                "total_duration_hours": round(total_stockout_duration_hours, 2),
                "total_unfulfilled_units": total_backlog_impact,
                "events_detail": stockout_events
            }
        }
