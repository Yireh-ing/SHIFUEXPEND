"""
Utilidades Matemáticas y Calculadoras de Ingeniería Logística.
Punto de Reorden (ROP), Stock de Seguridad, EOQ y Coeficiente Bullwhip.
"""

import math
from typing import List, Optional


def calculate_safety_stock(
    service_level_z: float = 1.65,
    std_dev_demand: float = 4.5,
    lead_time_days: int = 3
) -> int:
    """
    Calcula el Stock de Seguridad (Safety Stock - SS) utilizando el factor Z de nivel de servicio:
    SS = Z * sigma_d * sqrt(LeadTime)
    
    :param service_level_z: Factor Z para el nivel de servicio deseado (ej. 1.65 para 95%, 1.96 para 97.5%)
    :param std_dev_demand: Desviación estándar de la demanda diaria (sigma_d)
    :param lead_time_days: Tiempo de reabastecimiento en días (L)
    :return: Unidades enteras de stock de seguridad recomendadas
    """
    if lead_time_days <= 0 or std_dev_demand < 0 or service_level_z < 0:
        return 0

    ss = service_level_z * std_dev_demand * math.sqrt(lead_time_days)
    return math.ceil(ss)


def calculate_reorder_point(
    expected_daily_demand: float,
    lead_time_days: int,
    safety_stock: Optional[int] = None,
    service_level_z: float = 1.65,
    std_dev_demand: float = 4.5
) -> int:
    """
    Calcula el Punto de Reorden (ROP):
    ROP = (Demanda Promedio Diaria * Lead Time) + Stock de Seguridad
    """
    if safety_stock is None:
        safety_stock = calculate_safety_stock(service_level_z, std_dev_demand, lead_time_days)

    lead_time_demand = expected_daily_demand * lead_time_days
    rop = lead_time_demand + safety_stock
    return math.ceil(max(0.0, rop))


def calculate_eoq(
    annual_demand: float,
    order_setup_cost: float = 50.0,
    annual_holding_cost_per_unit: float = 5.0
) -> int:
    """
    Calcula la Cantidad Económica de Pedido (EOQ - Economic Order Quantity):
    EOQ = sqrt((2 * D * S) / H)
    """
    if annual_demand <= 0 or order_setup_cost <= 0 or annual_holding_cost_per_unit <= 0:
        return 0

    eoq = math.sqrt((2.0 * annual_demand * order_setup_cost) / annual_holding_cost_per_unit)
    return math.ceil(eoq)


def calculate_bullwhip_ratio(
    demand_history: List[float],
    orders_history: List[float]
) -> float:
    """
    Calcula la relación de Efecto Látigo (Bullwhip Effect Ratio):
    BWR = Var(Órdenes) / Var(Demanda)
    Si BWR > 1.0, existe amplificación de variabilidad en la cadena de suministro.
    """
    if len(demand_history) < 2 or len(orders_history) < 2:
        return 1.0

    mean_d = sum(demand_history) / len(demand_history)
    var_d = sum((x - mean_d) ** 2 for x in demand_history) / (len(demand_history) - 1)

    mean_o = sum(orders_history) / len(orders_history)
    var_o = sum((x - mean_o) ** 2 for x in orders_history) / (len(orders_history) - 1)

    if var_d == 0:
        return 1.0 if var_o == 0 else 2.0

    return round(var_o / var_d, 4)
