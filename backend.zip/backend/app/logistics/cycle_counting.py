"""
Planificador de Conteos Cíclicos de Almacén con Clasificación ABC.
Optimiza la exactitud del registro de inventario (IRA) minimizando disrupciones operativas.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import math


class CycleCountingScheduler:
    """
    Genera cronogramas de conteo cíclico para almacén basados en estratificación ABC de Pareto.
    """

    # Frecuencia de conteo por año recomendada
    COUNT_FREQUENCIES = {
        "A": 52,  # Semanal (52 conteos al año)
        "B": 12,  # Mensual (12 conteos al año)
        "C": 4    # Trimestral (4 conteos al año)
    }

    @staticmethod
    def classify_abc(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Clasifica una lista de artículos según su valor monetario anual de consumo (80/15/5).
        Cada item debe contener: 'sku', 'name', 'annual_usage', 'unit_cost'.
        """
        if not items:
            return []

        # Calcular valor total anual por ítem
        for item in items:
            item["annual_value"] = item.get("annual_usage", 0) * item.get("unit_cost", 0.0)

        # Ordenar descendente por valor monetario
        sorted_items = sorted(items, key=lambda x: x["annual_value"], reverse=True)
        total_inventory_value = sum(x["annual_value"] for x in sorted_items)

        cumulative_value = 0.0
        for idx, item in enumerate(sorted_items):
            prev_cumulative_pct = (cumulative_value / total_inventory_value) * 100 if total_inventory_value > 0 else 0
            cumulative_value += item["annual_value"]
            curr_cumulative_pct = (cumulative_value / total_inventory_value) * 100 if total_inventory_value > 0 else 0

            if idx == 0 or prev_cumulative_pct < 80.0:
                item["category"] = "A"
            elif prev_cumulative_pct < 95.0:
                item["category"] = "B"
            else:
                item["category"] = "C"

            item["annual_counts"] = CycleCountingScheduler.COUNT_FREQUENCIES[item["category"]]

        return sorted_items

    @classmethod
    def generate_weekly_schedule(
        cls,
        classified_items: List[Dict[str, Any]],
        start_date: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """
        Genera el calendario semanal de conteo cíclico distribuyendo los SKUs equitativamente.
        """
        if start_date is None:
            start_date = datetime.now()

        # Separar por categorías
        group_a = [i for i in classified_items if i.get("category") == "A"]
        group_b = [i for i in classified_items if i.get("category") == "B"]
        group_c = [i for i in classified_items if i.get("category") == "C"]

        schedule = []
        for week in range(1, 5):  # Cronograma de las próximas 4 semanas del mes
            week_date = start_date + timedelta(weeks=week - 1)
            
            # Todos los items de clase A se cuentan semanalmente
            items_to_count = [item["sku"] for item in group_a]

            # Dividir clase B en 4 semanas para que cada ítem se cuente 1 vez al mes
            b_chunk_size = max(1, math.ceil(len(group_b) / 4)) if group_b else 0
            b_start = (week - 1) * b_chunk_size
            items_to_count.extend([item["sku"] for item in group_b[b_start : b_start + b_chunk_size]])

            # Dividir clase C en semanas (rotación de 13 semanas por trimestre)
            c_chunk_size = max(1, math.ceil(len(group_c) / 12)) if group_c else 0
            c_start = (week - 1) * c_chunk_size
            items_to_count.extend([item["sku"] for item in group_c[c_start : c_start + c_chunk_size]])

            schedule.append({
                "week_number": week,
                "target_date": week_date.strftime("%Y-%m-%d"),
                "total_items_to_count": len(items_to_count),
                "sku_list": items_to_count
            })

        return schedule
