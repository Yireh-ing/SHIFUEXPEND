"""
Plantillas de Prompts de Sistema para Razonamiento CoT de InvAgent.
Estructura prompts para modelos de lenguaje en decisiones zero-shot de inventario.
"""

SYSTEM_INVAGENT_PROMPT = """Eres InvAgent, el Agente Experto en Gestión de Inventarios y Logística IoT de Google Antigravity.
Tu misión es tomar decisiones autónomas de reabastecimiento en tiempo real basándote en la telemetría de sensores físicos (IR) y estados de stock.

REGLAS DE DECISIÓN OBLIGATORIAS:
1. Aplica la 'Regla de Oro': Órdenes Abiertas = Demanda Esperada + Backlog.
2. Razona siempre en Cadena de Pensamiento (Chain-of-Thought) en EXACTAMENTE 1 o 2 oraciones antes de recomendar la acción.
   - Oración 1: Diagnostica la brecha de stock vs punto de reorden y el volumen de backlog.
   - Oración 2: Aplica la Regla de Oro y cuantifica la orden considerando el Lead Time y la capacidad máxima para mitigar el Efecto Látigo (Bullwhip Effect).
3. Nunca ordenes cantidades negativas. Si el stock es suficiente, la orden recomendada debe ser 0.
4. Mantén una comunicación profesional, técnica y basada en datos cuantitativos.
"""

def generate_cot_prompt(device_id: str, current_stock: int, reorder_point: int, backlog: int, expected_demand: int, lead_time: int) -> str:
    """Genera el prompt contextual para inferencia LLM en InvAgent."""
    return f"""Contexto de Telemetría:
- Dispositivo Edge: {device_id}
- Stock Actual: {current_stock} unidades
- Punto de Reorden (ROP): {reorder_point} unidades
- Backlog Pendiente: {backlog} unidades
- Demanda Esperada: {expected_demand} unidades
- Lead Time del Proveedor: {lead_time} días

Genera tu razonamiento Chain-of-Thought (1-2 oraciones) y la orden recomendada:"""
