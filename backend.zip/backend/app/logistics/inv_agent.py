"""
Motor de Decisión Logística InvAgent con Razonamiento Chain-of-Thought (CoT) Zero-Shot.
Aplica la Regla de Oro: 'Órdenes Abiertas = Demanda Esperada + Backlog'
y amortigua el Efecto Látigo (Bullwhip Effect) regulando el lote con la capacidad de producción.
"""

from typing import Optional
from app.models.telemetry import LogisticsDecisionModel
from app.config import settings


class InvAgent:
    """
    Agente Inteligente de Cadena de Suministro inspirado en la arquitectura InvAgent.
    Ejecuta un ciclo de decisión formal estructurado:
    1. Percepción de inventario físico y telemetría Edge.
    2. Razonamiento CoT (Chain-of-Thought) en 1-2 oraciones diagnósticas y prescriptivas.
    3. Aplicación de la Regla de Oro y mitigación Bullwhip.
    """

    def __init__(self, max_capacity: Optional[int] = None):
        self.max_capacity = max_capacity or settings.MAX_PRODUCTION_CAPACITY_PER_ORDER

    def decide(
        self,
        current_stock: int,
        backlog: int,
        reorder_point: int,
        expected_demand: int,
        lead_time_days: int = 3,
        safety_stock: int = 10
    ) -> LogisticsDecisionModel:
        """
        Ejecuta la toma de decisiones zero-shot para el punto de inventario actual.
        """
        # 1. Aplicación estricta de la Regla de Oro:
        # Órdenes Abiertas = Demanda Esperada + Backlog
        open_orders = expected_demand + backlog

        # 2. Evaluación de posición de inventario y punto de reorden
        reorder_triggered = (current_stock <= reorder_point)

        # 3. Cálculo de la necesidad neta de reabastecimiento:
        # Posición de inventario proyectada = Stock Actual - Backlog
        # Nivel objetivo = (Demanda Esperada * Lead Time) + Stock de Seguridad
        target_inventory = (expected_demand * max(1, lead_time_days)) + safety_stock
        inventory_position = current_stock - backlog
        gross_shortfall = target_inventory - inventory_position

        # Amortiguación del efecto látigo:
        # Si no se disparó el punto de reorden y el stock supera la demanda del lead time,
        # evitamos sobre-pedidos. Si se disparó o hay backlog severo, pedimos lo necesario
        # acotado por la capacidad máxima de producción del proveedor para no amplificar varianza.
        if reorder_triggered or gross_shortfall > 0:
            unconstrained_order = max(open_orders, gross_shortfall)
            # Acotar por capacidad de producción
            recommended_order_qty = min(unconstrained_order, self.max_capacity)
        else:
            recommended_order_qty = 0

        # 4. Formulación del Razonamiento Chain-of-Thought (CoT) en 1-2 oraciones
        if reorder_triggered:
            sentence_1 = (
                f"El stock actual de {current_stock} unidades ha alcanzado o perforado el punto de reorden de {reorder_point} "
                f"con un backlog insatisfecho de {backlog} unidades."
            )
            sentence_2 = (
                f"Aplicando la Regla de Oro (Órdenes Abiertas = Demanda ({expected_demand}) + Backlog ({backlog}) = {open_orders}), "
                f"se determina un lote óptimo de {recommended_order_qty} unidades para cubrir el lead time de {lead_time_days} días sin exceder la capacidad máxima de {self.max_capacity}."
            )
        else:
            sentence_1 = (
                f"El nivel de stock de {current_stock} unidades se mantiene en zona segura por encima del punto de reorden de {reorder_point} "
                f"con un backlog controlado de {backlog} unidades."
            )
            sentence_2 = (
                f"Basado en la Regla de Oro y una demanda esperada de {expected_demand} unidades, el inventario proyectado satisface el ciclo de {lead_time_days} días, "
                f"manteniendo la recomendación de orden en {recommended_order_qty} para evitar el Efecto Látigo."
            )

        reasoning_cot = f"{sentence_1} {sentence_2}"

        return LogisticsDecisionModel(
            reasoning_cot=reasoning_cot,
            open_orders=open_orders,
            recommended_order_qty=recommended_order_qty,
            reorder_triggered=reorder_triggered
        )
