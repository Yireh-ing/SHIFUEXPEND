"""Paquete de aplicación del backend logístico IoT."""
