"""
Servicio Asíncrono de Integración con Polar.sh.
Permite gestionar productos, órdenes, checkout sessions y webhooks para reposición y monetización IoT.
Aplica límites de reintentos estrictos (máx 3 reintentos) con backoff exponencial y timeout.
"""

import asyncio
import random
from typing import Dict, Any, Optional
# pyrefly: ignore [missing-import]
import httpx

from app.config import settings
from app.logger import logger


class PolarService:
    """
    Cliente asíncrono y resiliente para la API REST v1 de Polar.sh.
    """

    def __init__(self):
        self.max_retries = settings.MAX_SENSOR_RETRIES
        self.timeout = settings.SENSOR_TIMEOUT_SECONDS

    def _get_headers(self) -> Dict[str, str]:
        """Construye los encabezados HTTP para autenticación con Organization Access Token."""
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "SistemaLogisticoIoT/1.0"
        }
        if settings.POLAR_ACCESS_TOKEN:
            headers["Authorization"] = f"Bearer {settings.POLAR_ACCESS_TOKEN}"
        return headers

    async def _request_with_retry(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Ejecuta una petición HTTP a Polar con límite estricto de reintentos (máx 3)
        y retroceso exponencial (exponential backoff) con jitter.
        """
        base_url = settings.polar_base_url
        url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        headers = self._get_headers()

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            for attempt in range(1, self.max_retries + 1):
                try:
                    logger.info(
                        f"Enviando solicitud {method} a Polar.sh en {url} (Intento {attempt}/{self.max_retries})",
                        extra={"endpoint": endpoint, "attempt": attempt}
                    )
                    response = await client.request(
                        method=method,
                        url=url,
                        headers=headers,
                        params=params,
                        json=json_data
                    )

                    if response.status_code in (200, 201):
                        data = response.json()
                        logger.info(
                            f"Respuesta exitosa de Polar.sh ({response.status_code}) para {endpoint}",
                            extra={"status_code": response.status_code}
                        )
                        return data
                    elif response.status_code in (401, 403):
                        logger.error(
                            f"Error de autenticación/autorización con Polar.sh ({response.status_code}): {response.text}",
                            extra={"status_code": response.status_code}
                        )
                        return {
                            "error": "AuthenticationError",
                            "status_code": response.status_code,
                            "detail": response.text
                        }
                    else:
                        logger.warning(
                            f"Polar.sh respondió con estado {response.status_code} en intento {attempt}: {response.text}"
                        )

                except (httpx.ConnectError, httpx.TimeoutException) as net_err:
                    logger.warning(
                        f"Fallo de conexión o timeout en intento {attempt}/{self.max_retries} hacia Polar.sh: {net_err}"
                    )
                except httpx.HTTPError as http_err:
                    logger.error(f"Error HTTP inesperado hacia Polar.sh: {http_err}", exc_info=True)
                except Exception as ex:
                    logger.error(f"Error imprevisto en cliente Polar.sh: {ex}", exc_info=True)

                if attempt < self.max_retries:
                    sleep_time = (2 ** (attempt - 1)) + random.uniform(0.1, 0.5)
                    logger.info(f"Esperando {sleep_time:.2f}s antes de reintentar solicitud a Polar.sh...")
                    await asyncio.sleep(sleep_time)

        logger.error(
            f"Se agotaron los {self.max_retries} reintentos sin éxito hacia Polar.sh endpoint {endpoint}."
        )
        return {
            "error": "MaxRetriesExceeded",
            "detail": f"Fallo al contactar Polar.sh tras {self.max_retries} reintentos."
        }

    async def check_connection(self) -> Dict[str, Any]:
        """
        Verifica el estado de conexión y credenciales con la API de Polar.sh.
        Consulta las organizaciones asociadas o el endpoint de usuario.
        """
        if not settings.POLAR_ACCESS_TOKEN:
            return {
                "connected": False,
                "environment": settings.POLAR_ENVIRONMENT,
                "base_url": settings.polar_base_url,
                "status": "missing_token",
                "message": "POLAR_ACCESS_TOKEN no está configurado en las variables de entorno."
            }

        endpoint = "organizations"
        if settings.POLAR_ORGANIZATION_ID:
            endpoint = f"organizations/{settings.POLAR_ORGANIZATION_ID}"

        result = await self._request_with_retry("GET", endpoint)

        if "error" in result:
            return {
                "connected": False,
                "environment": settings.POLAR_ENVIRONMENT,
                "base_url": settings.polar_base_url,
                "status": "error",
                "detail": result
            }

        return {
            "connected": True,
            "environment": settings.POLAR_ENVIRONMENT,
            "base_url": settings.polar_base_url,
            "status": "active",
            "organization_data": result
        }

    async def list_products(self, limit: int = 10, page: int = 1) -> Dict[str, Any]:
        """
        Obtiene el catálogo de productos registrados en Polar.sh.
        """
        params: Dict[str, Any] = {"limit": limit, "page": page}
        if settings.POLAR_ORGANIZATION_ID:
            params["organization_id"] = settings.POLAR_ORGANIZATION_ID

        return await self._request_with_retry("GET", "products", params=params)

    async def list_orders(self, limit: int = 10, page: int = 1) -> Dict[str, Any]:
        """
        Obtiene las órdenes registradas en Polar.sh.
        """
        params: Dict[str, Any] = {"limit": limit, "page": page}
        if settings.POLAR_ORGANIZATION_ID:
            params["organization_id"] = settings.POLAR_ORGANIZATION_ID

        return await self._request_with_retry("GET", "orders", params=params)

    async def create_checkout_session(
        self,
        product_id: str,
        success_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Crea una sesión de checkout en Polar.sh para compra o reposición de stock.
        """
        payload: Dict[str, Any] = {
            "products": [product_id]
        }
        if success_url:
            payload["success_url"] = success_url

        return await self._request_with_retry("POST", "checkouts", json_data=payload)

    async def process_webhook(self, event_payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Procesa eventos de webhook entrantes desde Polar.sh (ej. order.created, subscription.created).
        """
        event_type = event_payload.get("type", "unknown")
        data = event_payload.get("data", {})
        logger.info(
            f"Evento de webhook Polar recibido: {event_type}",
            extra={"event_type": event_type}
        )

        # Mapeo a flujos de reposición logística si aplica
        if event_type == "order.created":
            order_id = data.get("id")
            amount = data.get("amount")
            logger.info(
                f"Orden procesada en Polar.sh ID={order_id}, monto={amount}. Sincronizando con flujo de abastecimiento."
            )
            return {
                "status": "processed",
                "action": "inventory_order_recorded",
                "order_id": order_id
            }

        return {
            "status": "acknowledged",
            "event_type": event_type
        }


polar_service = PolarService()
