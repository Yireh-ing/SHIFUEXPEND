"""
Servicio Asíncrono de Ingesta, Polling y Resiliencia para Telemetría Edge IoT.
Aplica límites de reintentos estrictos (máx 3 reintentos) con backoff exponencial.
"""

import asyncio
import random
from typing import Optional, Dict, Any
from datetime import datetime, timezone
# pyrefly: ignore [missing-import]
import httpx

from app.config import settings
from app.logger import logger
from app.models.telemetry import TelemetryPayload, SensorDataModel, InventoryStateModel
from app.logistics.inv_agent import InvAgent
from app.services.mailtrap_service import mailtrap_service


class TelemetryService:
    """
    Gestiona la comunicación con el microcontrolador ESP32 y coordina la ejecución de InvAgent.
    """

    def __init__(self):
        self.esp32_url = f"http://{settings.ESP32_IP}:{settings.ESP32_PORT}/api/v1/telemetry"
        self.inv_agent = InvAgent()
        self.latest_telemetry: Optional[TelemetryPayload] = None

    async def fetch_telemetry_with_retry(self) -> Optional[TelemetryPayload]:
        """
        Consulta la telemetría del ESP32 con límite estricto de reintentos (máx 3)
        y retroceso exponencial (exponential backoff) con jitter.
        """
        max_retries = settings.MAX_SENSOR_RETRIES
        timeout = settings.SENSOR_TIMEOUT_SECONDS

        async with httpx.AsyncClient(timeout=timeout) as client:
            for attempt in range(1, max_retries + 1):
                try:
                    logger.info(
                        f"Intentando obtener telemetría desde ESP32 en {self.esp32_url} (Intento {attempt}/{max_retries})"
                    )
                    response = await client.get(self.esp32_url)

                    if response.status_code == 200:
                        payload_data = response.json()
                        telemetry = TelemetryPayload.model_validate(payload_data)
                        logger.info(
                            f"Telemetría recibida exitosamente desde {telemetry.device_id}",
                            extra={"device_id": telemetry.device_id}
                        )
                        return telemetry
                    else:
                        logger.warning(
                            f"ESP32 respondió con código HTTP {response.status_code}: {response.text}"
                        )

                except (httpx.ConnectError, httpx.TimeoutException) as net_err:
                    logger.warning(
                        f"Fallo de conexión en intento {attempt}/{max_retries} hacia ESP32: {net_err}"
                    )
                except Exception as ex:
                    logger.error(f"Error inesperado al consultar sensor ESP32: {ex}", exc_info=True)

                if attempt < max_retries:
                    # Backoff exponencial con jitter (1s, 2s, 4s...)
                    sleep_time = (2 ** (attempt - 1)) + random.uniform(0.1, 0.5)
                    logger.info(f"Esperando {sleep_time:.2f}s antes del siguiente reintento...")
                    await asyncio.sleep(sleep_time)

        logger.error(
            f"Se alcanzó el límite máximo de {max_retries} reintentos sin éxito. Conexión con ESP32 fallida."
        )
        return None

    async def process_telemetry(self, raw_data: Dict[str, Any]) -> TelemetryPayload:
        """
        Valida el payload entrante contra schema.json, ejecuta InvAgent y despacha alertas.
        """
        # 1. Validación de esquema
        telemetry = TelemetryPayload.model_validate(raw_data)

        # 2. Invocación de InvAgent con CoT y Regla de Oro
        decision = self.inv_agent.decide(
            current_stock=telemetry.inventory_state.current_stock,
            backlog=telemetry.inventory_state.backlog,
            reorder_point=telemetry.inventory_state.reorder_point,
            expected_demand=telemetry.inventory_state.expected_demand,
            lead_time_days=telemetry.inventory_state.lead_time_days or 3,
            safety_stock=telemetry.inventory_state.safety_stock or 10
        )

        telemetry.logistics_decision = decision
        self.latest_telemetry = telemetry

        # 3. Notificación automática por Mailtrap si se activó reorden
        if decision.reorder_triggered:
            asyncio.create_task(mailtrap_service.send_reorder_alert(telemetry, decision))

        return telemetry


telemetry_service = TelemetryService()
