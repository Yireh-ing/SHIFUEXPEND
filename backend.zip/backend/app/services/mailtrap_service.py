"""
Servicio Asíncrono de Notificaciones y Alertas con Mailtrap.
Implementa construcción de emails enriquecidos con MIMEMultipart,
imágenes incrustadas con Content-ID (CID) y reportes de inventario adjuntos.
"""

import os
import csv
import io
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
from datetime import datetime, timezone
from typing import Dict, Any, Optional

# pyrefly: ignore [missing-import]
import aiosmtplib

from app.config import settings
from app.logger import logger
from app.models.telemetry import TelemetryPayload, LogisticsDecisionModel


# Generación en memoria de un banner SVG o PNG base para incrustación CID
ALERT_BANNER_SVG = """<svg xmlns="http://www.w3.org/2000/svg" width="600" height="120" viewBox="0 0 600 120">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#dc2626;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#991b1b;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="600" height="120" rx="10" fill="url(#grad)"/>
  <text x="30" y="50" font-family="Arial, sans-serif" font-size="24" font-weight="bold" fill="#ffffff">
    ALERTA DE PUNTO DE REORDEN
  </text>
  <text x="30" y="85" font-family="Arial, sans-serif" font-size="14" fill="#fecaca">
    Sistema Autonomo de Gestion Logistica e Inventario IoT con IA Multi-Agente
  </text>
  <circle cx="540" cy="60" r="25" fill="#ffffff" fill-opacity="0.2"/>
  <polygon points="540,45 555,75 525,75" fill="#fef08a"/>
  <rect x="538" y="53" width="4" height="12" fill="#7f1d1d"/>
  <circle cx="540" cy="70" r="2.5" fill="#7f1d1d"/>
</svg>""".encode("utf-8")


class MailtrapNotificationService:
    """
    Servicio de envío de correos asíncronos enriquecidos hacia Mailtrap.
    """

    def __init__(self):
        self.host = settings.MAILTRAP_HOST
        self.port = settings.MAILTRAP_PORT
        self.username = settings.MAILTRAP_USERNAME
        self.password = settings.MAILTRAP_PASSWORD
        self.sender = settings.MAILTRAP_SENDER_EMAIL
        self.recipient = settings.ALERT_RECIPIENT_EMAIL

    def build_stockout_report_csv(self, telemetry: TelemetryPayload, decision: LogisticsDecisionModel) -> str:
        """Genera un archivo CSV en memoria con el reporte formal de la auditoría de stock."""
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Parametro", "Valor", "Descripcion"])
        writer.writerow(["Device ID", telemetry.device_id, "Identificador del sensor Edge"])
        writer.writerow(["Timestamp", telemetry.timestamp.isoformat(), "Fecha y hora del evento"])
        writer.writerow(["Stock Actual", telemetry.inventory_state.current_stock, "Unidades fisicas presentes"])
        writer.writerow(["Punto de Reorden", telemetry.inventory_state.reorder_point, "Umbral de disparo"])
        writer.writerow(["Backlog Pendiente", telemetry.inventory_state.backlog, "Unidades demandadas pendientes"])
        writer.writerow(["Demanda Esperada", telemetry.inventory_state.expected_demand, "Proyeccion de consumo del ciclo"])
        writer.writerow(["Lead Time (Dias)", telemetry.inventory_state.lead_time_days, "Tiempo de entrega proveedor"])
        writer.writerow(["Regla de Oro (Ordenes Abiertas)", decision.open_orders, "Demanda + Backlog"])
        writer.writerow(["Lote Recomendado", decision.recommended_order_qty, "Pedido ajustado mitigando Bullwhip"])
        writer.writerow(["Razonamiento CoT", decision.reasoning_cot, "Cadena de pensamiento de InvAgent"])
        return output.getvalue()

    def build_email_message(
        self,
        telemetry: TelemetryPayload,
        decision: LogisticsDecisionModel
    ) -> MIMEMultipart:
        """
        Construye el mensaje MIME multipart/related enriquecido con HTML, imagen CID y adjunto CSV.
        """
        # Estructura raíz: multipart/related para incrustación de recursos CID
        msg_root = MIMEMultipart("related")
        msg_root["Subject"] = f"CRITICO: Reposición Requerida - Dispositivo {telemetry.device_id} [Stock: {telemetry.inventory_state.current_stock}]"
        msg_root["From"] = self.sender
        msg_root["To"] = self.recipient
        msg_root["Date"] = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")

        # Contenedor alternativo para texto plano y HTML
        msg_alternative = MIMEMultipart("alternative")
        msg_root.attach(msg_alternative)

        # Versión Texto Plano de Respaldo
        text_content = (
            f"ALERTA DE REORDEN DE INVENTARIO\n"
            f"Dispositivo: {telemetry.device_id}\n"
            f"Stock Actual: {telemetry.inventory_state.current_stock} unidades (Punto de Reorden: {telemetry.inventory_state.reorder_point})\n"
            f"Backlog: {telemetry.inventory_state.backlog} unidades | Demanda Esperada: {telemetry.inventory_state.expected_demand}\n"
            f"Orden Recomendada: {decision.recommended_order_qty} unidades\n\n"
            f"Razonamiento InvAgent: {decision.reasoning_cot}\n"
        )
        msg_alternative.attach(MIMEText(text_content, "plain", "utf-8"))

        # Versión HTML Enriquecida con diseño moderno y soporte Dark Mode
        html_content = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
          <meta charset="utf-8">
          <style>
            body {{ font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }}
            .container {{ max-width: 620px; margin: 0 auto; background-color: #1e293b; border-radius: 12px; overflow: hidden; border: 1px solid #334155; }}
            .header-img {{ width: 100%; display: block; border-bottom: 2px solid #ef4444; }}
            .content {{ padding: 24px; }}
            .badge {{ display: inline-block; padding: 4px 12px; border-radius: 9999px; font-weight: bold; font-size: 12px; text-transform: uppercase; background-color: #ef4444; color: #ffffff; }}
            .table-container {{ margin: 20px 0; border-collapse: collapse; width: 100%; border-radius: 8px; overflow: hidden; }}
            .table-container th {{ background-color: #334155; text-align: left; padding: 10px 14px; font-size: 13px; color: #94a3b8; }}
            .table-container td {{ background-color: #1e293b; padding: 12px 14px; border-bottom: 1px solid #334155; font-size: 14px; color: #e2e8f0; }}
            .highlight-val {{ font-weight: bold; color: #f87171; }}
            .success-val {{ font-weight: bold; color: #34d399; }}
            .cot-box {{ background-color: #0f172a; border-left: 4px solid #38bdf8; padding: 16px; border-radius: 4px; margin: 20px 0; }}
            .cot-title {{ font-size: 12px; font-weight: bold; color: #38bdf8; text-transform: uppercase; margin-bottom: 6px; }}
            .cot-text {{ font-size: 14px; line-height: 1.5; color: #cbd5e1; font-style: italic; }}
            .footer {{ text-align: center; padding: 16px; font-size: 12px; color: #64748b; background-color: #0f172a; border-top: 1px solid #334155; }}
          </style>
        </head>
        <body>
          <div class="container">
            <!-- Imagen Incrustada por CID -->
            <img src="cid:alert_banner" alt="Alerta Reorden" class="header-img"/>
            <div class="content">
              <span class="badge">Nivel de Stock Crítico</span>
              <h2 style="margin-top: 12px; color: #f8fafc;">Disparo de Reorden en Sensor {telemetry.device_id}</h2>
              <p style="color: #94a3b8; font-size: 14px;">
                La lectura en tiempo real del sensor infrarrojo (IR: {telemetry.sensor_data.ir_status}) indica que el inventario físico ha caído al umbral de seguridad.
              </p>

              <table class="table-container">
                <thead>
                  <tr><th>Métrica</th><th>Valor Actual</th><th>Umbral / Meta</th></tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Stock en Ubicación</td>
                    <td class="highlight-val">{telemetry.inventory_state.current_stock} un.</td>
                    <td>ROP: {telemetry.inventory_state.reorder_point} un.</td>
                  </tr>
                  <tr>
                    <td>Backlog Acumulado</td>
                    <td class="highlight-val">{telemetry.inventory_state.backlog} un.</td>
                    <td>0 un.</td>
                  </tr>
                  <tr>
                    <td>Demanda Esperada (Ciclo)</td>
                    <td>{telemetry.inventory_state.expected_demand} un.</td>
                    <td>Lead Time: {telemetry.inventory_state.lead_time_days} días</td>
                  </tr>
                  <tr>
                    <td>Lote de Pedido Recomendado</td>
                    <td class="success-val">{decision.recommended_order_qty} un.</td>
                    <td>Cap. Máx: {settings.MAX_PRODUCTION_CAPACITY_PER_ORDER} un.</td>
                  </tr>
                </tbody>
              </table>

              <!-- Razonamiento Chain-of-Thought (InvAgent) -->
              <div class="cot-box">
                <div class="cot-title">🧠 InvAgent Chain-of-Thought Decision Log</div>
                <div class="cot-text">"{decision.reasoning_cot}"</div>
              </div>

              <p style="font-size: 13px; color: #94a3b8;">
                Se ha adjuntado el informe detallado en formato CSV para su procesamiento en el ERP o sistema logístico central.
              </p>
            </div>
            <div class="footer">
              Generado automáticamente por Antigravity IoT Logistics Engine &bull; {telemetry.timestamp.isoformat()}
            </div>
          </div>
        </body>
        </html>
        """
        msg_alternative.attach(MIMEText(html_content, "html", "utf-8"))

        # 1. Adjuntar Imagen Incrustada via Content-ID (CID)
        image_part = MIMEImage(ALERT_BANNER_SVG, _subtype="svg+xml")
        image_part.add_header("Content-ID", "<alert_banner>")
        image_part.add_header("Content-Disposition", "inline", filename="alert_banner.svg")
        msg_root.attach(image_part)

        # 2. Adjuntar Reporte de Auditoría CSV
        csv_data = self.build_stockout_report_csv(telemetry, decision)
        csv_part = MIMEApplication(csv_data.encode("utf-8"), _subtype="csv")
        csv_filename = f"reporte_reorden_{telemetry.device_id}_{int(telemetry.timestamp.timestamp())}.csv"
        csv_part.add_header("Content-Disposition", "attachment", filename=csv_filename)
        msg_root.attach(csv_part)

        return msg_root

    async def send_reorder_alert(
        self,
        telemetry: TelemetryPayload,
        decision: LogisticsDecisionModel
    ) -> bool:
        """
        Envía la alerta por correo electrónico utilizando aiosmtplib con reintentos controlados.
        """
        if not decision.reorder_triggered:
            logger.info("Stock en niveles normales. No se requiere envío de alerta.", extra={"device_id": telemetry.device_id})
            return False

        message = self.build_email_message(telemetry, decision)

        # Si no se configuraron credenciales reales de Mailtrap, realizar simulación segura (Dry-Run)
        if not self.username or not self.password or self.username == "":
            logger.warning(
                "[MAILTRAP DRY-RUN] Credenciales SMTP de Mailtrap no provistas (MAILTRAP_USERNAME/MAILTRAP_PASSWORD vacías). "
                f"Alerta simulada con éxito para device={telemetry.device_id}, stock={telemetry.inventory_state.current_stock}, "
                f"lote_recomendado={decision.recommended_order_qty}.",
                extra={"device_id": telemetry.device_id, "context": {"reorder_qty": decision.recommended_order_qty}}
            )
            return True

        try:
            logger.info(f"Conectando a Mailtrap SMTP ({self.host}:{self.port}) para enviar alerta de reorden...")
            await aiosmtplib.send(
                message,
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                start_tls=True,
                timeout=10.0
            )
            logger.info(
                f"[MAILTRAP SUCCESS] Correo de alerta enviado exitosamente a {self.recipient}",
                extra={"device_id": telemetry.device_id}
            )
            return True
        except aiosmtplib.SMTPException as smtp_err:
            logger.error(f"[MAILTRAP SMTP ERROR] Falló el despacho de alerta: {smtp_err}", exc_info=True)
            return False
        except Exception as ex:
            logger.error(f"[MAILTRAP UNEXPECTED ERROR] Error imprevisto al enviar alerta: {ex}", exc_info=True)
            return False


mailtrap_service = MailtrapNotificationService()
