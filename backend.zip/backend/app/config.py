"""
Módulo de Configuración y Validación de Variables de Entorno.
Cumple con la regla de tolerancia cero a credenciales hardcodeadas y validación obligatoria.
"""

import os
from typing import Optional
# pyrefly: ignore [missing-import]
from pydantic import BaseModel, Field


class Settings(BaseModel):
    # Variables de Entorno Obligatorias
    MAILTRAP_API_KEY: str = Field(
        default_factory=lambda: os.getenv("MAILTRAP_API_KEY", "")
    )
    ESP32_IP: str = Field(
        default_factory=lambda: os.getenv("ESP32_IP", "192.168.1.150")
    )
    
    # Parámetros de Red y Telemetría
    ESP32_PORT: int = Field(
        default_factory=lambda: int(os.getenv("ESP32_PORT", "80"))
    )
    MAX_SENSOR_RETRIES: int = Field(
        default_factory=lambda: int(os.getenv("MAX_SENSOR_RETRIES", "3"))
    )
    SENSOR_TIMEOUT_SECONDS: float = Field(
        default_factory=lambda: float(os.getenv("SENSOR_TIMEOUT_SECONDS", "3.0"))
    )
    POLLING_INTERVAL_SECONDS: int = Field(
        default_factory=lambda: int(os.getenv("POLLING_INTERVAL_SECONDS", "10"))
    )

    # Configuración de Correo / Mailtrap
    MAILTRAP_HOST: str = Field(
        default_factory=lambda: os.getenv("MAILTRAP_HOST", "sandbox.smtp.mailtrap.io")
    )
    MAILTRAP_PORT: int = Field(
        default_factory=lambda: int(os.getenv("MAILTRAP_PORT", "2525"))
    )
    MAILTRAP_USERNAME: str = Field(
        default_factory=lambda: os.getenv("MAILTRAP_USERNAME", "")
    )
    MAILTRAP_PASSWORD: str = Field(
        default_factory=lambda: os.getenv("MAILTRAP_PASSWORD", "")
    )
    MAILTRAP_SENDER_EMAIL: str = Field(
        default_factory=lambda: os.getenv("MAILTRAP_SENDER_EMAIL", "logistica-ai@empresa.com")
    )
    ALERT_RECIPIENT_EMAIL: str = Field(
        default_factory=lambda: os.getenv("ALERT_RECIPIENT_EMAIL", "gerente-inventarios@empresa.com")
    )

    # Persistencia Externa (Supabase / MCP)
    SUPABASE_URL: Optional[str] = Field(
        default_factory=lambda: os.getenv("SUPABASE_URL", "")
    )
    SUPABASE_KEY: Optional[str] = Field(
        default_factory=lambda: os.getenv("SUPABASE_KEY", "")
    )

    # Integración Polar (Polar.sh - Monetización, Órdenes y Checkout)
    POLAR_ACCESS_TOKEN: Optional[str] = Field(
        default_factory=lambda: os.getenv("POLAR_ACCESS_TOKEN", "")
    )
    POLAR_ORGANIZATION_ID: Optional[str] = Field(
        default_factory=lambda: os.getenv("POLAR_ORGANIZATION_ID", "")
    )
    POLAR_ENVIRONMENT: str = Field(
        default_factory=lambda: os.getenv("POLAR_ENVIRONMENT", "sandbox")
    )
    POLAR_WEBHOOK_SECRET: Optional[str] = Field(
        default_factory=lambda: os.getenv("POLAR_WEBHOOK_SECRET", "")
    )

    @property
    def polar_base_url(self) -> str:
        if self.POLAR_ENVIRONMENT.lower() == "production":
            return "https://api.polar.sh/v1"
        return "https://sandbox-api.polar.sh/v1"

    # Integración Stellar Network & Smart Wallets IoT
    STELLAR_NETWORK: str = Field(
        default_factory=lambda: os.getenv("STELLAR_NETWORK", "TESTNET")
    )
    STELLAR_HORIZON_URL: str = Field(
        default_factory=lambda: os.getenv("STELLAR_HORIZON_URL", "https://horizon-testnet.stellar.org")
    )
    STELLAR_OPERATOR_SECRET_KEY: Optional[str] = Field(
        default_factory=lambda: os.getenv("STELLAR_OPERATOR_SECRET_KEY", "")
    )
    STELLAR_OPERATOR_PUBLIC_KEY: Optional[str] = Field(
        default_factory=lambda: os.getenv("STELLAR_OPERATOR_PUBLIC_KEY", "")
    )
    STELLAR_FRIENDBOT_URL: str = Field(
        default_factory=lambda: os.getenv("STELLAR_FRIENDBOT_URL", "https://friendbot.stellar.org")
    )
    STELLAR_AUTO_FUND_TESTNET: bool = Field(
        default_factory=lambda: os.getenv("STELLAR_AUTO_FUND_TESTNET", "true").lower() in ("true", "1", "yes")
    )

    # Parámetros de Capacidad de Producción y Filtro Bullwhip
    MAX_PRODUCTION_CAPACITY_PER_ORDER: int = Field(
        default_factory=lambda: int(os.getenv("MAX_PRODUCTION_CAPACITY", "200"))
    )

    def validate_critical_keys(self) -> None:
        """
        Valida la presencia de las variables críticas obligatorias según las reglas del workspace.
        """
        missing = []
        if not self.MAILTRAP_API_KEY and not (self.MAILTRAP_USERNAME and self.MAILTRAP_PASSWORD):
            missing.append("MAILTRAP_API_KEY (o MAILTRAP_USERNAME / MAILTRAP_PASSWORD)")
        if not self.ESP32_IP:
            missing.append("ESP32_IP")

        if missing:
            warning_msg = (
                f"[SECURITY ALERT] Variables críticas ausentes en el entorno: {', '.join(missing)}. "
                "Para producción o pruebas reales, asegúrate de definir estas variables en tu archivo .env o contenedor."
            )
            # Imprimir advertencia visible sin abortar en modo prueba o mock si se utilizan simuladores
            print(warning_msg)


settings = Settings()
