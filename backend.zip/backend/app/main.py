"""
Punto de Entrada Principal - Backend Asíncrono FastAPI.
Orquesta Telemetría IoT, InvAgent (CoT), Alertas Mailtrap y MCP Gateway.
"""

import asyncio
from contextlib import asynccontextmanager
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone

# pyrefly: ignore [missing-import]
from fastapi import FastAPI, HTTPException, status, BackgroundTasks
# pyrefly: ignore [missing-import]
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.logger import logger
from app.models.telemetry import (
    TelemetryPayload,
    LogisticsDecisionModel,
    SensorDataModel,
    InventoryStateModel
)
from app.services.telemetry_service import telemetry_service
from app.services.mailtrap_service import mailtrap_service
from app.services.polar_service import polar_service
from app.services.stellar_service import stellar_service
from app.models.stellar import (
    SmartWalletInfo,
    CreateSmartWalletRequest,
    ContactlessPaymentPayload,
    ContactlessTapRequest,
    PaymentReceipt
)
from app.logistics.inv_agent import InvAgent
from app.logistics.cycle_counting import CycleCountingScheduler
from app.logistics.analytics import LogisticsAnalytics
from app.logistics.calculators import (
    calculate_reorder_point,
    calculate_safety_stock
)


# Tarea de fondo para sondeo periódico del ESP32
async def background_esp32_polling():
    logger.info("Iniciando tarea de fondo para polling continuo de ESP32...")
    while True:
        try:
            if settings.ESP32_IP:
                telemetry = await telemetry_service.fetch_telemetry_with_retry()
                if telemetry:
                    await telemetry_service.process_telemetry(telemetry.model_dump())
        except asyncio.CancelledError:
            logger.info("Tarea de polling de ESP32 detenida.")
            break
        except Exception as e:
            logger.error(f"Error en bucle de polling: {e}", exc_info=True)

        await asyncio.sleep(settings.POLLING_INTERVAL_SECONDS)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Validación de variables críticas al iniciar
    logger.info("=== INICIANDO SISTEMA LOGISTICO IOT CON IA MULTI-AGENTE ===")
    settings.validate_critical_keys()
    
    # 2. Iniciar polling en segundo plano solo si no estamos en entorno estricto de pruebas
    polling_task = asyncio.create_task(background_esp32_polling())
    yield
    # Limpieza al apagar
    polling_task.cancel()
    try:
        await polling_task
    except asyncio.CancelledError:
        pass
    logger.info("=== SISTEMA LOGISTICO IOT DETENIDO CORRECTAMENTE ===")


app = FastAPI(
    title="Sistema Autónomo de Gestión Logística e Inventario IoT con IA Multi-Agente",
    description="Backend asíncrono con integración ESP32/Pico, InvAgent (CoT), Mailtrap y Servidores MCP",
    version="1.0.0",
    lifespan=lifespan
)

# Configuración de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", tags=["General"])
async def root():
    return {
        "system": "Sistema Autónomo de Gestión Logística e Inventario IoT con IA Multi-Agente",
        "status": "online",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "architecture": {
            "edge": "Raspberry Pi Pico (MicroPython) & ESP32 (C++ Async)",
            "backend": "Python 3.11+ Asyncio / FastAPI",
            "logistics_ai": "InvAgent Zero-Shot CoT Engine",
            "notifications": "Mailtrap MIMEMultipart Service",
            "mcp": ["Supabase", "GitHub", "n8n", "Polar.sh"],
            "monetization": "Polar.sh Digital Products, Orders & Checkout",
            "blockchain_settlement": "Stellar Smart Wallets & Contactless Pay"
        }
    }


@app.get("/health", tags=["General"])
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "esp32_target": f"http://{settings.ESP32_IP}:{settings.ESP32_PORT}",
        "mailtrap_configured": bool(settings.MAILTRAP_API_KEY or settings.MAILTRAP_USERNAME),
        "polar_configured": bool(settings.POLAR_ACCESS_TOKEN),
        "polar_environment": settings.POLAR_ENVIRONMENT,
        "stellar_network": settings.STELLAR_NETWORK,
        "stellar_horizon": settings.STELLAR_HORIZON_URL
    }


@app.post("/api/v1/telemetry", response_model=TelemetryPayload, tags=["Telemetría IoT"])
async def receive_telemetry(payload: Dict[str, Any]):
    """
    Recibe datos de telemetría desde el Gateway ESP32 o sensores Edge.
    Valida contra schema.json, procesa decisiones con InvAgent y dispara alertas si aplica.
    """
    try:
        processed = await telemetry_service.process_telemetry(payload)
        return processed
    except Exception as e:
        logger.error(f"Error procesando telemetría entrante: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Fallo de validación o procesamiento en el contrato: {str(e)}"
        )


@app.get("/api/v1/telemetry", response_model=TelemetryPayload, tags=["Telemetría IoT"])
async def get_current_telemetry():
    """Retorna la telemetría actual del gateway (compatible con el endpoint GET del ESP32)."""
    return await get_latest_telemetry()


@app.get("/api/v1/telemetry/latest", response_model=TelemetryPayload, tags=["Telemetría IoT"])
async def get_latest_telemetry():
    """Retorna la última lectura de telemetría procesada por el sistema."""
    if not telemetry_service.latest_telemetry:
        # Generar un estado base si aún no se ha recibido telemetría
        sample_data = {
            "device_id": "DEFAULT-EDGE-01",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "sensor_data": {"ir_status": 1, "item_count": 0, "sampling_rate_ms": 100},
            "inventory_state": {
                "current_stock": 120,
                "backlog": 0,
                "reorder_point": 30,
                "expected_demand": 25,
                "lead_time_days": 3,
                "safety_stock": 10
            }
        }
        await telemetry_service.process_telemetry(sample_data)

    return telemetry_service.latest_telemetry


@app.post("/api/v1/logistics/evaluate", response_model=LogisticsDecisionModel, tags=["Motor InvAgent"])
async def evaluate_inventory_decision(
    current_stock: int,
    backlog: int,
    reorder_point: int,
    expected_demand: int,
    lead_time_days: int = 3,
    safety_stock: int = 10
):
    """
    Ejecuta el motor InvAgent con razonamiento Chain-of-Thought (1-2 oraciones)
    y aplica la Regla de Oro para el reabastecimiento sin efecto látigo.
    """
    agent = InvAgent()
    decision = agent.decide(
        current_stock=current_stock,
        backlog=backlog,
        reorder_point=reorder_point,
        expected_demand=expected_demand,
        lead_time_days=lead_time_days,
        safety_stock=safety_stock
    )
    return decision


@app.get("/api/v1/logistics/cycle-counting", tags=["Logística & Almacén"])
async def get_cycle_counting_schedule():
    """Genera el cronograma de conteo cíclico mensual estratificado por clasificación ABC."""
    sample_inventory = [
        {"sku": "SKU-A01", "name": "Módulo Sensor IR Óptico", "annual_usage": 4500, "unit_cost": 25.0},
        {"sku": "SKU-A02", "name": "Controlador ESP32-WROOM-32D", "annual_usage": 3200, "unit_cost": 30.0},
        {"sku": "SKU-B01", "name": "Fuente de Poder 5V 2A", "annual_usage": 1800, "unit_cost": 8.5},
        {"sku": "SKU-B02", "name": "Gabinete Industrial IP65", "annual_usage": 900, "unit_cost": 15.0},
        {"sku": "SKU-C01", "name": "Cable DuPont 20cm", "annual_usage": 5000, "unit_cost": 0.20},
        {"sku": "SKU-C02", "name": "LEDs Indicadores 5mm", "annual_usage": 8000, "unit_cost": 0.05}
    ]
    classified = CycleCountingScheduler.classify_abc(sample_inventory)
    schedule = CycleCountingScheduler.generate_weekly_schedule(classified)
    return {
        "classified_items": classified,
        "monthly_schedule": schedule
    }


@app.get("/api/v1/logistics/analytics", tags=["Logística & Almacén"])
async def get_weekly_analytics():
    """Retorna el resumen analítico semanal de rotación (ITR) y eventos de rotura de stock."""
    mock_stockout_events = [
        {
            "event_id": "EVT-2026-09-01",
            "sku": "SKU-A01",
            "duration_hours": 3.5,
            "unfulfilled_units": 15,
            "root_cause": "Retraso en transporte de proveedor"
        }
    ]
    summary = LogisticsAnalytics.generate_weekly_summary(
        cogs_week=12500.0,
        avg_inventory_value=85000.0,
        stockout_events=mock_stockout_events,
        total_demand_units=650,
        fulfilled_units=635
    )
    return summary


@app.post("/api/v1/alerts/test-email", tags=["Notificaciones Mailtrap"])
async def trigger_test_email(background_tasks: BackgroundTasks):
    """Dispara un correo de prueba con MIMEMultipart, banner CID y adjunto CSV hacia Mailtrap."""
    mock_payload = TelemetryPayload(
        device_id="TEST-DEVICE-01",
        timestamp=datetime.now(timezone.utc),
        sensor_data=SensorDataModel(ir_status=0, item_count=42, sampling_rate_ms=100),
        inventory_state=InventoryStateModel(
            current_stock=18,
            backlog=12,
            reorder_point=30,
            expected_demand=25,
            lead_time_days=3,
            safety_stock=10
        )
    )
    inv_agent = InvAgent()
    decision = inv_agent.decide(
        current_stock=18,
        backlog=12,
        reorder_point=30,
        expected_demand=25,
        lead_time_days=3,
        safety_stock=10
    )

    background_tasks.add_task(mailtrap_service.send_reorder_alert, mock_payload, decision)

    return {
        "status": "alert_dispatched",
        "recipient": settings.ALERT_RECIPIENT_EMAIL,
        "mode": "live" if settings.MAILTRAP_USERNAME else "dry-run-logged",
        "decision": decision
    }


@app.get("/api/v1/logistics/calculators/rop", tags=["Logística & Almacén"])
async def compute_reorder_point(
    daily_demand: float,
    lead_time_days: int,
    std_dev_demand: float = 4.5,
    service_level_z: float = 1.65
):
    """Calcula el Punto de Reorden (ROP) y Stock de Seguridad basándose en la variabilidad de la demanda."""
    ss = calculate_safety_stock(service_level_z, std_dev_demand, lead_time_days)
    rop = calculate_reorder_point(daily_demand, lead_time_days, ss)
    return {
        "expected_daily_demand": daily_demand,
        "lead_time_days": lead_time_days,
        "safety_stock": ss,
        "reorder_point": rop
    }


# ==========================================
# RUTAS DE INTEGRACIÓN CON POLAR.SH
# ==========================================

@app.get("/api/v1/polar/status", tags=["Monetización & Polar.sh"])
async def get_polar_status():
    """
    Verifica el estado de la conexión con la API de Polar.sh,
    validando la configuración del entorno y credenciales de la organización.
    """
    try:
        status_info = await polar_service.check_connection()
        return status_info
    except Exception as e:
        logger.error(f"Error verificando conectividad con Polar.sh: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Fallo al verificar estado de Polar.sh: {str(e)}"
        )


@app.get("/api/v1/polar/products", tags=["Monetización & Polar.sh"])
async def get_polar_products(limit: int = 10, page: int = 1):
    """
    Consulta el catálogo de productos disponibles en Polar.sh
    (dispositivos IoT, repuestos y licencias asociadas).
    """
    try:
        products = await polar_service.list_products(limit=limit, page=page)
        return products
    except Exception as e:
        logger.error(f"Error obteniendo productos de Polar.sh: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error consultando productos en Polar.sh: {str(e)}"
        )


@app.get("/api/v1/polar/orders", tags=["Monetización & Polar.sh"])
async def get_polar_orders(limit: int = 10, page: int = 1):
    """
    Consulta el historial de órdenes y compras registradas en Polar.sh.
    """
    try:
        orders = await polar_service.list_orders(limit=limit, page=page)
        return orders
    except Exception as e:
        logger.error(f"Error obteniendo órdenes de Polar.sh: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error consultando órdenes en Polar.sh: {str(e)}"
        )


@app.post("/api/v1/polar/checkout", tags=["Monetización & Polar.sh"])
async def create_polar_checkout(product_id: str, success_url: Optional[str] = None):
    """
    Genera una sesión de checkout en Polar.sh para compra de reposición o hardware.
    """
    try:
        session = await polar_service.create_checkout_session(product_id=product_id, success_url=success_url)
        return session
    except Exception as e:
        logger.error(f"Error generando checkout session en Polar.sh: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creando checkout session en Polar.sh: {str(e)}"
        )


@app.post("/api/v1/polar/webhook", tags=["Monetización & Polar.sh"])
async def handle_polar_webhook(payload: Dict[str, Any]):
    """
    Endpoint receptor de eventos de Webhook desde Polar.sh (order.created, subscription.created).
    """
    try:
        result = await polar_service.process_webhook(payload)
        return result
    except Exception as e:
        logger.error(f"Error procesando webhook de Polar.sh: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error procesando webhook: {str(e)}"
        )


# ==========================================
# RUTAS DE STELLAR SMART WALLETS & PAGO POR CONTACTO
# ==========================================

@app.post(
    "/api/v1/stellar/wallets",
    response_model=SmartWalletInfo,
    tags=["Stellar Smart Wallets & Contactless"]
)
async def create_smart_wallet(request: CreateSmartWalletRequest):
    """
    Aprovisiona un nuevo Smart Wallet programable para un nodo o dispositivo Edge en Stellar.
    """
    try:
        wallet = await stellar_service.create_smart_wallet(request)
        return wallet
    except Exception as e:
        logger.error(f"Error aprovisionando Smart Wallet: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creando Smart Wallet: {str(e)}"
        )


@app.get(
    "/api/v1/stellar/wallets",
    response_model=List[SmartWalletInfo],
    tags=["Stellar Smart Wallets & Contactless"]
)
async def list_smart_wallets():
    """Lista todas las Smart Wallets gestionadas por el clúster logístico."""
    return stellar_service.list_wallets()


@app.get(
    "/api/v1/stellar/wallets/{wallet_id}",
    response_model=SmartWalletInfo,
    tags=["Stellar Smart Wallets & Contactless"]
)
async def get_smart_wallet(wallet_id: str):
    """Consulta la información y saldo actualizado en Stellar Horizon de un Smart Wallet."""
    wallet = stellar_service.get_wallet(wallet_id)
    if not wallet:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Smart Wallet '{wallet_id}' no encontrada."
        )
    # Actualizar balance on-chain
    wallet.balance_xlm = await stellar_service.get_account_balance(wallet.public_key)
    return wallet


@app.post(
    "/api/v1/stellar/contactless/payload",
    response_model=ContactlessPaymentPayload,
    tags=["Stellar Smart Wallets & Contactless"]
)
async def generate_contactless_payload(
    destination: str,
    amount: str,
    memo: str,
    asset_code: str = "XLM"
):
    """
    Genera el payload criptográfico contactless (SEP-0007 URI y registro NFC NDEF)
    con nonce anti-replay y firma HMAC para etiquetas NFC o terminales móviles.
    """
    try:
        payload = stellar_service.generate_contactless_payload(
            destination=destination,
            amount=amount,
            memo=memo,
            asset_code=asset_code
        )
        return payload
    except Exception as e:
        logger.error(f"Error generando payload contactless: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error generando payload contactless: {str(e)}"
        )


@app.post(
    "/api/v1/stellar/contactless/tap",
    response_model=PaymentReceipt,
    tags=["Stellar Smart Wallets & Contactless"]
)
async def process_contactless_tap(request: ContactlessTapRequest):
    """
    Procesa un evento de contacto físico (NFC Tap) emitido por hardware Edge o lector móvil.
    Verifica firma, previene replay attacks, valida límites de Smart Wallet y liquida en Stellar.
    """
    try:
        receipt = await stellar_service.execute_contactless_tap(request)
        return receipt
    except ValueError as ve:
        logger.warning(f"Rechazo de política o seguridad en pago contactless: {ve}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(ve)
        )
    except Exception as e:
        logger.error(f"Error ejecutando pago contactless en Stellar: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Fallo al procesar pago contactless en Stellar: {str(e)}"
        )


@app.post(
    "/api/v1/stellar/delivery-payment",
    response_model=PaymentReceipt,
    tags=["Stellar Smart Wallets & Contactless"]
)
async def trigger_delivery_flow_payment(
    device_id: str,
    supplier_destination: str,
    amount: str,
    delivery_batch_id: str
):
    """
    Flujo autónomo IoT: Cuando los sensores confirman la recepción de lote de material,
    el Smart Wallet del nodo Edge ejecuta automáticamente la liquidación por contacto.
    """
    try:
        receipt = await stellar_service.execute_delivery_flow_payment(
            device_id=device_id,
            supplier_destination=supplier_destination,
            amount=amount,
            delivery_batch_id=delivery_batch_id
        )
        return receipt
    except Exception as e:
        logger.error(f"Error en flujo de pago autónomo por recepción: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error en liquidación de entrega: {str(e)}"
        )



