"""
Modelos de Datos para Smart Wallets y Pagos por Contacto en Stellar Network.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
# pyrefly: ignore [missing-import]
from pydantic import BaseModel, Field


class SmartWalletInfo(BaseModel):
    """Información pública del Smart Wallet del nodo o dispositivo IoT."""
    wallet_id: str = Field(..., description="Identificador único del wallet dentro del clúster logístico")
    public_key: str = Field(..., description="Clave pública de Stellar (G...)")
    device_id: Optional[str] = Field(None, description="Dispositivo IoT asociado (ESP32 / Pico / Gateway)")
    network: str = Field("TESTNET", description="Red de Stellar (TESTNET / PUBLIC)")
    balance_xlm: float = Field(0.0, description="Saldo disponible en Lumens (XLM)")
    spending_limit_per_tx: float = 100.0
    daily_limit: float = 500.0
    daily_spent: float = 0.0
    is_active: bool = True
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())



class CreateSmartWalletRequest(BaseModel):
    """Solicitud para aprovisionar un Smart Wallet para un nodo Edge."""
    wallet_id: str = Field(..., description="ID legible del wallet (ej. WALLET-ESP32-GATEWAY-ZONE-A)")
    device_id: Optional[str] = Field(None, description="ID del microcontrolador / sensor")
    spending_limit_per_tx: float = Field(100.0, ge=0.1, description="Límite por transacción (XLM)")
    daily_limit: float = Field(500.0, ge=1.0, description="Límite diario acumulado (XLM)")
    fund_via_friendbot: bool = Field(True, description="Si es True y estamos en testnet, fondear automáticamente")


class ContactlessPaymentPayload(BaseModel):
    """
    Payload criptográfico para pagos por contacto (NFC / QR / SEP-0007).
    Diseñado para chips NFC NDEF o escaneo óptico por terminal de entrega.
    """
    destination: str = Field(..., description="Cuenta receptora Stellar (G...)")
    amount: str = Field(..., description="Monto a transferir en XLM con precisión decimal")
    asset_code: str = Field("XLM", description="Código del activo (XLM o custom asset)")
    memo: str = Field(..., description="Memo de auditoría logística (ej. ROP-BATCH-42)")
    nonce: str = Field(..., description="Token efímero de un solo uso para prevenir ataques de repetición")
    timestamp: str = Field(..., description="Marca de tiempo ISO-8601 de emisión del contacto")
    signature: str = Field(..., description="Firma criptográfica de verificación del nodo emisor")
    stellar_uri: str = Field(..., description="URI estándar SEP-0007 (web+stellar:pay)")
    nfc_ndef_record: str = Field(..., description="Cadena formateada para tag NFC NDEF")


class ContactlessTapRequest(BaseModel):
    """Petición generada cuando el hardware Edge o terminal realiza contacto físico."""
    payer_wallet_id: str = Field(..., description="ID del Smart Wallet origen que autoriza el pago")
    payload: ContactlessPaymentPayload = Field(..., description="Payload leído por el lector contactless")


class PaymentReceipt(BaseModel):
    """Comprobante de transacción ejecutada en Stellar."""
    tx_hash: str = Field(..., description="Hash de la transacción en el ledger de Stellar")
    ledger: Optional[int] = Field(None, description="Número de ledger donde se confirmó")
    source: str = Field(..., description="Clave pública de origen")
    destination: str = Field(..., description="Clave pública receptora")
    amount: str = Field(..., description="Monto transferido")
    asset: str = Field("XLM", description="Activo transferido")
    memo: str = Field(..., description="Memo registrado en la blockchain")
    status: str = Field("confirmed", description="Estado de la transacción (confirmed, failed)")
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    explorer_url: str = Field(..., description="Enlace al explorador de bloques (StellarExpert)")
