"""
Modelos de Datos Pydantic para Validación del Contrato schema.json.
"""

from datetime import datetime
from typing import Optional
# pyrefly: ignore [missing-import]
from pydantic import BaseModel, Field


class SensorDataModel(BaseModel):
    ir_status: int = Field(
        ...,
        ge=0,
        le=1,
        description="Estado del sensor infrarrojo: 0 objeto detectado, 1 ausencia"
    )
    item_count: int = Field(
        ...,
        ge=0,
        description="Conteo acumulado de ítems"
    )
    sampling_rate_ms: Optional[int] = Field(
        default=100,
        ge=10,
        description="Tasa de muestreo en milisegundos"
    )
    rssi_dbm: Optional[float] = Field(
        default=None,
        description="Intensidad de señal WiFi en dBm"
    )


class InventoryStateModel(BaseModel):
    current_stock: int = Field(
        ...,
        ge=0,
        description="Stock físico disponible actual"
    )
    backlog: int = Field(
        ...,
        ge=0,
        description="Órdenes pendientes insatisfechas"
    )
    reorder_point: int = Field(
        ...,
        ge=0,
        description="Umbral de punto de reorden"
    )
    expected_demand: int = Field(
        ...,
        ge=0,
        description="Demanda prevista para el siguiente periodo"
    )
    lead_time_days: Optional[int] = Field(
        default=3,
        ge=1,
        description="Días de tiempo de entrega del proveedor"
    )
    safety_stock: Optional[int] = Field(
        default=10,
        ge=0,
        description="Inventario de seguridad"
    )


class LogisticsDecisionModel(BaseModel):
    reasoning_cot: str = Field(
        ...,
        description="Razonamiento Chain-of-Thought conciso en 1-2 oraciones"
    )
    open_orders: int = Field(
        ...,
        ge=0,
        description="Órdenes calculadas mediante la Regla de Oro: Demanda + Backlog"
    )
    recommended_order_qty: int = Field(
        ...,
        ge=0,
        description="Lote de reabastecimiento recomendado considerando amortiguación Bullwhip"
    )
    reorder_triggered: bool = Field(
        ...,
        description="Indica si el stock actual rompió el punto de reorden"
    )


class TelemetryPayload(BaseModel):
    device_id: str = Field(
        ...,
        min_length=3,
        max_length=64,
        pattern=r"^[a-zA-Z0-9_-]+$",
        description="Identificador del dispositivo Edge"
    )
    timestamp: datetime = Field(
        ...,
        description="Marca de tiempo en formato ISO-8601"
    )
    sensor_data: SensorDataModel
    inventory_state: InventoryStateModel
    logistics_decision: Optional[LogisticsDecisionModel] = Field(
        default=None,
        description="Metadatos generados por el motor InvAgent con razonamiento Chain-of-Thought"
    )
