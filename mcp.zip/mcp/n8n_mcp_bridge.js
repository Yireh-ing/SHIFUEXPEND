/**
 * @file n8n_mcp_bridge.js
 * @brief Puente MCP ligero para disparar webhooks en n8n y orquestar flujos logísticos y alertas Mailtrap.
 */

const http = require('http');
const https = require('https');

const N8N_URL = process.env.N8N_WEBHOOK_URL || 'https://n8n.internal.local/webhook/logistics-event';
const API_KEY = process.env.N8N_API_KEY || '';

console.error('[MCP n8n Bridge] Servidor iniciado. Escuchando directivas de automatización...');

process.stdin.on('data', async (chunk) => {
    try {
        const input = JSON.parse(chunk.toString());
        // Respuesta conforme a JSON-RPC / MCP
        const response = {
            jsonrpc: "2.0",
            id: input.id || null,
            result: {
                status: "success",
                message: "Evento derivado al flujo n8n",
                timestamp: new Date().toISOString()
            }
        };
        process.stdout.write(JSON.stringify(response) + "\n");
    } catch (e) {
        process.stdout.write(JSON.stringify({ jsonrpc: "2.0", error: { code: -32700, message: "Parse error" } }) + "\n");
    }
});
