---
trigger: always_on
---

# Reglas del Workspace - Sistema Logístico IoT con IA Multi-Agente

1. **Arquitectura Backend**: Usar Python asincrónico (`asyncio`, `FastAPI`, `httpx`, `aiosmtplib`) con estructuración modular limpia.
2. **Hardware Edge**: MicroPython para Raspberry Pi Pico (GP15 sensor IR active-low, GP14 LED) y C++ asíncrono para ESP32 (`ESPAsyncWebServer`, `ArduinoJson`).
3. **Seguridad Obligatoria**:
   - Prohibido hardcodear credenciales o secretos en el código fuente.
   - Carga estricta mediante `os.getenv` de variables de entorno: `MAILTRAP_API_KEY`, `ESP32_IP`, `SUPABASE_URL`, `SUPABASE_KEY`, etc.
   - Validación temprana (fail-fast) en la inicialización del sistema.
4. **Manejo de Errores & Resiliencia**:
   - Bloques try-except explícitos con captura tipada.
   - Límite de reintentos estricto (máximo 3 reintentos) con backoff exponencial y timeout para lecturas de sensores y peticiones HTTP.
   - Logging estructurado en formato JSON para trazabilidad y auditoría.