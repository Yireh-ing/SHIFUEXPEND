"""
Pruebas de Construcción del Mensaje MIMEMultipart y Enriquecimiento Mailtrap.
"""

from datetime import datetime, timezone

# pyrefly: ignore [missing-import]
from app.models.telemetry import TelemetryPayload, SensorDataModel, InventoryStateModel
# pyrefly: ignore [missing-import]
from app.logistics.inv_agent import InvAgent
# pyrefly: ignore [missing-import]
from app.services.mailtrap_service import MailtrapNotificationService


def test_mailtrap_mime_multipart_structure():
    """
    Verifica que el correo contenga estructura multipart/related, imagen con CID y reporte CSV adjunto.
    """
    service = MailtrapNotificationService()
    telemetry = TelemetryPayload(
        device_id="PICO-WAREHOUSE-A",
        timestamp=datetime.now(timezone.utc),
        sensor_data=SensorDataModel(ir_status=0, item_count=50),
        inventory_state=InventoryStateModel(
            current_stock=15,
            backlog=10,
            reorder_point=30,
            expected_demand=25,
            lead_time_days=3,
            safety_stock=10
        )
    )

    agent = InvAgent()
    decision = agent.decide(15, 10, 30, 25, 3, 10)

    msg = service.build_email_message(telemetry, decision)

    # 1. Verificar tipo principal MIME
    assert msg.get_content_type() == "multipart/related"

    # 2. Verificar cabeceras estándar
    assert "CRITICO: Reposición Requerida" in msg["Subject"]
    assert "PICO-WAREHOUSE-A" in msg["Subject"]

    # 3. Inspeccionar las partes del mensaje
    payload_parts = list(msg.walk())
    part_types = [p.get_content_type() for p in payload_parts]

    assert "text/html" in part_types
    assert "text/plain" in part_types
    assert "image/svg+xml" in part_types
    assert "application/csv" in part_types or "text/csv" in part_types or any("csv" in pt for pt in part_types)

    # 4. Verificar presencia del Content-ID <alert_banner>
    cid_headers = [p.get("Content-ID") for p in payload_parts if p.get("Content-ID")]
    assert "<alert_banner>" in cid_headers

    # 5. Verificar presencia de adjunto CSV en Content-Disposition
    dispositions = [
        str(p.get("Content-Disposition"))
        for p in payload_parts
        if p.get("Content-Disposition") is not None
    ]
    assert any("attachment" in d and "reporte_reorden" in d for d in dispositions)
