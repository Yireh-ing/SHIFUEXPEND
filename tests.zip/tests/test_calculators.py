"""
Pruebas Unitarias de Fórmulas Logísticas, Conteos Cíclicos y Analítica.
"""

# pyrefly: ignore [missing-import]
from app.logistics.calculators import (
    calculate_safety_stock,
    calculate_reorder_point,
    calculate_eoq,
    calculate_bullwhip_ratio
)
# pyrefly: ignore [missing-import]
from app.logistics.cycle_counting import CycleCountingScheduler
# pyrefly: ignore [missing-import]
from app.logistics.analytics import LogisticsAnalytics


def test_safety_stock_and_reorder_point():
    # Demanda diaria = 10, lead time = 4 días, sigma_d = 2, Z = 1.65 (95%)
    # SS = 1.65 * 2 * sqrt(4) = 1.65 * 4 = 6.6 -> ceil = 7
    ss = calculate_safety_stock(service_level_z=1.65, std_dev_demand=2.0, lead_time_days=4)
    assert ss == 7

    # ROP = (10 * 4) + 7 = 47
    rop = calculate_reorder_point(
        expected_daily_demand=10,
        lead_time_days=4,
        safety_stock=ss
    )
    assert rop == 47


def test_eoq_calculation():
    # D = 1000 unidades/año, S = $50 por orden, H = $2.50 por unidad/año
    # EOQ = sqrt((2 * 1000 * 50) / 2.50) = sqrt(100000 / 2.50) = sqrt(40000) = 200
    eoq = calculate_eoq(annual_demand=1000, order_setup_cost=50.0, annual_holding_cost_per_unit=2.50)
    assert eoq == 200


def test_bullwhip_ratio():
    # Demanda estable vs pedidos altamente volátiles
    demand = [10.0, 10.0, 10.0, 10.0, 10.0]
    orders = [0.0, 25.0, 0.0, 30.0, 0.0]
    ratio = calculate_bullwhip_ratio(demand, orders)
    assert ratio > 1.0


def test_cycle_counting_abc_pareto():
    items = [
        {"sku": "SKU-HIGH", "annual_usage": 1000, "unit_cost": 100.0},  # $100k
        {"sku": "SKU-MED", "annual_usage": 500, "unit_cost": 20.0},     # $10k
        {"sku": "SKU-LOW", "annual_usage": 1000, "unit_cost": 1.0}      # $1k
    ]
    classified = CycleCountingScheduler.classify_abc(items)
    assert classified[0]["category"] == "A"
    assert classified[0]["annual_counts"] == 52

    schedule = CycleCountingScheduler.generate_weekly_schedule(classified)
    assert len(schedule) == 4
    assert "SKU-HIGH" in schedule[0]["sku_list"]


def test_logistics_analytics_summary():
    events = [{"event_id": "1", "duration_hours": 2.0, "unfulfilled_units": 5}]
    summary = LogisticsAnalytics.generate_weekly_summary(
        cogs_week=10000.0,
        avg_inventory_value=50000.0,
        stockout_events=events,
        total_demand_units=500,
        fulfilled_units=495
    )
    assert summary["kpis"]["fill_rate_percentage"] == 99.0
    assert summary["stockout_analysis"]["total_incidents"] == 1
