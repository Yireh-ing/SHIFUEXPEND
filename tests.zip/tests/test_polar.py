"""
Pruebas Unitarias y de Integración para la Conexión con Polar.sh.
Valida autenticación, consultas resilientes con retry limit, endpoints y webhook handling.
"""

import pytest
import respx
import httpx
from unittest.mock import patch

from app.config import settings
from app.services.polar_service import PolarService
from app.main import app
from httpx import AsyncClient, ASGITransport


@pytest.mark.asyncio
async def test_polar_status_missing_token():
    """Valida la respuesta cuando POLAR_ACCESS_TOKEN no está presente."""
    service = PolarService()
    with patch.object(settings, "POLAR_ACCESS_TOKEN", ""):
        status_info = await service.check_connection()
        assert status_info["connected"] is False
        assert status_info["status"] == "missing_token"


@pytest.mark.asyncio
async def test_polar_connection_success():
    """Valida la verificación exitosa de conexión con Polar.sh con token válido."""
    service = PolarService()
    mock_org_data = {
        "items": [
            {
                "id": "org_12345",
                "name": "Logistics IoT Corp",
                "slug": "logistics-iot"
            }
        ],
        "pagination": {"total_count": 1, "max_page": 1}
    }

    with patch.object(settings, "POLAR_ACCESS_TOKEN", "polar_oat_valid_token_test"), \
         patch.object(settings, "POLAR_ORGANIZATION_ID", ""):
        
        base_url = settings.polar_base_url
        with respx.mock(base_url=base_url) as respx_mock:
            respx_mock.get("/organizations").mock(
                return_value=httpx.Response(200, json=mock_org_data)
            )

            result = await service.check_connection()
            assert result["connected"] is True
            assert result["status"] == "active"
            assert "organization_data" in result
            assert result["organization_data"]["items"][0]["id"] == "org_12345"


@pytest.mark.asyncio
async def test_polar_retry_limit_exhaustion():
    """
    Verifica que las llamadas HTTP a Polar cumplan la regla de tolerancia a fallos
    con límite estricto de máx 3 reintentos ante caídas de red.
    """
    service = PolarService()
    base_url = settings.polar_base_url

    with patch.object(settings, "POLAR_ACCESS_TOKEN", "polar_oat_test"), \
         patch.object(settings, "MAX_SENSOR_RETRIES", 3):
        
        with respx.mock(base_url=base_url) as respx_mock:
            route = respx_mock.get("/products").mock(
                side_effect=httpx.ConnectError("Simulated Polar API downtime")
            )

            result = await service.list_products()
            assert "error" in result
            assert result["error"] == "MaxRetriesExceeded"
            assert route.call_count == 3


@pytest.mark.asyncio
async def test_polar_list_products_success():
    """Valida la recuperación del catálogo de productos desde Polar.sh."""
    service = PolarService()
    mock_products = {
        "items": [
            {
                "id": "prod_sensor_ir_01",
                "name": "Módulo Sensor IR Digital",
                "is_recurring": False,
                "prices": [{"amount": 2500, "currency": "usd"}]
            }
        ],
        "pagination": {"total_count": 1, "max_page": 1}
    }
    base_url = settings.polar_base_url

    with patch.object(settings, "POLAR_ACCESS_TOKEN", "polar_oat_test"):
        with respx.mock(base_url=base_url) as respx_mock:
            respx_mock.get("/products").mock(
                return_value=httpx.Response(200, json=mock_products)
            )

            result = await service.list_products()
            assert "items" in result
            assert len(result["items"]) == 1
            assert result["items"][0]["name"] == "Módulo Sensor IR Digital"


@pytest.mark.asyncio
async def test_polar_create_checkout_session():
    """Valida la generación de checkout sessions en Polar.sh."""
    service = PolarService()
    mock_checkout = {
        "id": "chk_session_abc123",
        "url": "https://sandbox.polar.sh/checkout/chk_session_abc123",
        "status": "open",
        "product_id": "prod_sensor_ir_01"
    }
    base_url = settings.polar_base_url

    with patch.object(settings, "POLAR_ACCESS_TOKEN", "polar_oat_test"):
        with respx.mock(base_url=base_url) as respx_mock:
            respx_mock.post("/checkouts").mock(
                return_value=httpx.Response(201, json=mock_checkout)
            )

            session = await service.create_checkout_session(
                product_id="prod_sensor_ir_01",
                success_url="https://empresa.com/orders/success"
            )
            assert session["id"] == "chk_session_abc123"
            assert "url" in session


@pytest.mark.asyncio
async def test_polar_webhook_order_created():
    """Valida el procesamiento de webhooks para eventos de orden en Polar.sh."""
    service = PolarService()
    webhook_event = {
        "type": "order.created",
        "data": {
            "id": "ord_998877",
            "amount": 5000,
            "currency": "usd",
            "customer_id": "cust_12345"
        }
    }

    result = await service.process_webhook(webhook_event)
    assert result["status"] == "processed"
    assert result["action"] == "inventory_order_recorded"
    assert result["order_id"] == "ord_998877"


@pytest.mark.asyncio
async def test_api_polar_endpoints():
    """Prueba los endpoints de FastAPI para Polar.sh a través de AsyncClient ASGI."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # 1. Endpoint /api/v1/polar/status
        status_res = await client.get("/api/v1/polar/status")
        assert status_res.status_code == 200
        data = status_res.json()
        assert "connected" in data

        # 2. Endpoint /api/v1/polar/webhook
        webhook_payload = {
            "type": "order.created",
            "data": {"id": "ord_test_01", "amount": 1000}
        }
        hook_res = await client.post("/api/v1/polar/webhook", json=webhook_payload)
        assert hook_res.status_code == 200
        assert hook_res.json()["action"] == "inventory_order_recorded"
