"""
Pruebas de Validación del Contrato schema.json y Modelos Pydantic.
"""

import json
# pyrefly: ignore [missing-import]
import pytest
import jsonschema

# pyrefly: ignore [missing-import]
from app.models.telemetry import TelemetryPayload


@pytest.fixture
def raw_schema():
    with open("schema.json", "r", encoding="utf-8") as f:
        return json.load(f)


def test_schema_valid_payload(raw_schema):
    """Verifica que un payload válido cumpla con schema.json."""
    sample_payload = {
        "device_id": "PICO-EDGE-01",
        "timestamp": "2026-09-25T10:30:00Z",
        "sensor_data": {
            "ir_status": 0,
            "item_count": 14,
            "sampling_rate_ms": 100,
            "rssi_dbm": -65.5
        },
        "inventory_state": {
            "current_stock": 25,
            "backlog": 5,
            "reorder_point": 30,
            "expected_demand": 20,
            "lead_time_days": 3,
            "safety_stock": 10
        }
    }

    # Validación JSON Schema estándar
    jsonschema.validate(instance=sample_payload, schema=raw_schema)

    # Validación Pydantic
    pydantic_obj = TelemetryPayload.model_validate(sample_payload)
    assert pydantic_obj.device_id == "PICO-EDGE-01"
    assert pydantic_obj.sensor_data.ir_status == 0
    assert pydantic_obj.inventory_state.current_stock == 25


def test_schema_missing_required_fields(raw_schema):
    """Verifica que falle si faltan campos obligatorios en el contrato."""
    invalid_payload = {
        "device_id": "PICO-EDGE-01",
        # Falta timestamp
        "sensor_data": {
            "ir_status": 0
            # Falta item_count
        },
        "inventory_state": {
            "current_stock": 25
            # Faltan backlog, reorder_point, expected_demand
        }
    }

    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=invalid_payload, schema=raw_schema)


def test_schema_invalid_ir_status(raw_schema):
    """Verifica que ir_status solo acepte 0 o 1."""
    invalid_payload = {
        "device_id": "PICO-EDGE-01",
        "timestamp": "2026-09-25T10:30:00Z",
        "sensor_data": {
            "ir_status": 5,  # Inválido, debe ser 0 o 1
            "item_count": 10
        },
        "inventory_state": {
            "current_stock": 25,
            "backlog": 0,
            "reorder_point": 30,
            "expected_demand": 20
        }
    }

    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=invalid_payload, schema=raw_schema)
