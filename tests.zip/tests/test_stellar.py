"""
Pruebas Unitarias y de Integración para Stellar Smart Wallets y Pagos por Contacto.
Valida aprovisionamiento de billeteras, límites de gasto, prevención de replay attacks,
formato de payload SEP-0007 / NFC NDEF y endpoints FastAPI.
"""

from stellar_sdk import Keypair
import pytest
import respx
import httpx
from unittest.mock import patch
from httpx import AsyncClient, ASGITransport

from app.config import settings
from app.services.stellar_service import StellarSmartWalletService
from app.models.stellar import (
    CreateSmartWalletRequest,
    ContactlessTapRequest
)
from app.main import app


@pytest.mark.asyncio
async def test_create_smart_wallet_offline():
    """Valida la generación de un Smart Wallet con par de claves Ed25519 válido."""
    service = StellarSmartWalletService()
    req = CreateSmartWalletRequest(
        wallet_id="WALLET-TEST-EDGE-01",
        device_id="ESP32-TEST-GATEWAY",
        spending_limit_per_tx=50.0,
        daily_limit=250.0,
        fund_via_friendbot=False
    )

    with respx.mock(base_url=settings.STELLAR_HORIZON_URL) as respx_mock:
        # Mock de consulta de saldo inicial 404 (cuenta aún no creada on-chain)
        respx_mock.get(url__regex=r".*/accounts/.*").mock(
            return_value=httpx.Response(404, text="Account not found")
        )

        wallet = await service.create_smart_wallet(req)
        assert wallet.wallet_id == "WALLET-TEST-EDGE-01"
        assert wallet.public_key.startswith("G")
        assert len(wallet.public_key) == 56
        assert wallet.spending_limit_per_tx == 50.0
        assert wallet.daily_limit == 250.0
        assert wallet.is_active is True


@pytest.mark.asyncio
async def test_generate_contactless_payload_format():
    """Valida que el payload cumpla con SEP-0007 y el estándar de tag NFC NDEF."""
    service = StellarSmartWalletService()
    dest = Keypair.random().public_key
    amount = "12.5"
    memo = "REORDER-BATCH-99"

    payload = service.generate_contactless_payload(
        destination=dest,
        amount=amount,
        memo=memo
    )

    # Validaciones del estándar
    assert payload.destination == dest
    assert payload.amount == amount
    assert payload.memo == memo
    assert len(payload.nonce) == 32  # 16 bytes hex
    assert payload.stellar_uri.startswith("web+stellar:pay?destination=")
    assert f"amount={amount}" in payload.stellar_uri
    assert f"memo={memo}" in payload.stellar_uri
    assert payload.nfc_ndef_record.startswith("stellar:pay;dest=")
    assert f"amt={amount}" in payload.nfc_ndef_record
    assert len(payload.signature) == 64  # SHA-256 hex


@pytest.mark.asyncio
async def test_execute_contactless_tap_success_and_replay_protection():
    """
    Valida la ejecución exitosa de un tap contactless y verifica que un segundo intento
    con el mismo nonce sea rechazado inmediatamente (prevención de Replay Attack).
    """
    service = StellarSmartWalletService()
    wallet_id = "WALLET-TAP-TEST-01"

    # 1. Crear el wallet pagador
    req = CreateSmartWalletRequest(
        wallet_id=wallet_id,
        spending_limit_per_tx=100.0,
        daily_limit=500.0,
        fund_via_friendbot=False
    )
    with respx.mock(base_url=settings.STELLAR_HORIZON_URL) as respx_mock:
        respx_mock.get(url__regex=r".*/accounts/.*").mock(
            return_value=httpx.Response(404, text="Not found")
        )
        wallet = await service.create_smart_wallet(req)

    dest_key = Keypair.random().public_key
    payload = service.generate_contactless_payload(
        destination=dest_key,
        amount="25.0",
        memo="PO-CONTACTLESS-01"
    )

    tap_req = ContactlessTapRequest(
        payer_wallet_id=wallet_id,
        payload=payload
    )

    # 2. Mock de Horizon: consulta de sequence y submit de transacción
    with respx.mock(base_url=settings.STELLAR_HORIZON_URL) as respx_mock:
        respx_mock.get(f"/accounts/{wallet.public_key}").mock(
            return_value=httpx.Response(200, json={"sequence": "1000", "balances": [{"asset_type": "native", "balance": "200.0"}]})
        )
        respx_mock.post("/transactions").mock(
            return_value=httpx.Response(200, json={"hash": "abcdef1234567890abcdef1234567890", "ledger": 123456})
        )

        receipt = await service.execute_contactless_tap(tap_req)
        assert receipt.status == "confirmed"
        assert receipt.tx_hash == "abcdef1234567890abcdef1234567890"
        assert receipt.ledger == 123456
        assert receipt.destination == dest_key
        assert "stellar.expert" in receipt.explorer_url

        # 3. Replay attack: intentar reutilizar el mismo payload/nonce
        with pytest.raises(ValueError, match="ya fue utilizado"):
            await service.execute_contactless_tap(tap_req)


@pytest.mark.asyncio
async def test_contactless_limit_enforcement():
    """Valida que transacciones que superen el límite configurado por tx sean bloqueadas."""
    service = StellarSmartWalletService()
    wallet_id = "WALLET-LIMIT-TEST"

    req = CreateSmartWalletRequest(
        wallet_id=wallet_id,
        spending_limit_per_tx=10.0,  # Máximo 10 XLM por tap
        daily_limit=50.0,
        fund_via_friendbot=False
    )
    with respx.mock(base_url=settings.STELLAR_HORIZON_URL) as respx_mock:
        respx_mock.get(url__regex=r".*/accounts/.*").mock(
            return_value=httpx.Response(404, text="Not found")
        )
        await service.create_smart_wallet(req)

    # Intentar pagar 15 XLM (excede límite de 10)
    dest_key = Keypair.random().public_key
    payload = service.generate_contactless_payload(
        destination=dest_key,
        amount="15.0",
        memo="OVERLIMIT-PAY"
    )
    tap_req = ContactlessTapRequest(
        payer_wallet_id=wallet_id,
        payload=payload
    )

    with pytest.raises(ValueError, match="excede el límite por transacción"):
        await service.execute_contactless_tap(tap_req)


@pytest.mark.asyncio
async def test_stellar_api_endpoints():
    """Valida los endpoints REST en FastAPI para Smart Wallets y Pagos Contactless."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # 1. Crear Smart Wallet
        create_payload = {
            "wallet_id": "WALLET-API-TEST",
            "device_id": "PICO-GP15-SENSOR",
            "spending_limit_per_tx": 50.0,
            "daily_limit": 200.0,
            "fund_via_friendbot": False
        }
        with respx.mock(base_url=settings.STELLAR_HORIZON_URL) as respx_mock:
            respx_mock.get(url__regex=r".*/accounts/.*").mock(
                return_value=httpx.Response(404, text="Not found")
            )
            create_res = await client.post("/api/v1/stellar/wallets", json=create_payload)
            assert create_res.status_code == 200
            data = create_res.json()
            assert data["wallet_id"] == "WALLET-API-TEST"
            assert data["public_key"].startswith("G")

        # 2. Listar Wallets
        list_res = await client.get("/api/v1/stellar/wallets")
        assert list_res.status_code == 200
        wallets = list_res.json()
        assert any(w["wallet_id"] == "WALLET-API-TEST" for w in wallets)

        # 3. Generar Contactless Payload
        dest_key = Keypair.random().public_key
        payload_res = await client.post(
            "/api/v1/stellar/contactless/payload",
            params={
                "destination": dest_key,
                "amount": "5.0",
                "memo": "NFC-TAP-DEMO"
            }
        )
        assert payload_res.status_code == 200
        nfc_data = payload_res.json()
        assert "nonce" in nfc_data
        assert "stellar_uri" in nfc_data
