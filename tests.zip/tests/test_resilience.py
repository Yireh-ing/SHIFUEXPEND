"""
Pruebas de Tolerancia a Fallos y Límites de Reintentos de Sensor.
"""

# pyrefly: ignore [missing-import]
import pytest
# pyrefly: ignore [missing-import]
import respx
# pyrefly: ignore [missing-import]
import httpx
# pyrefly: ignore [missing-import]
from app.services.telemetry_service import TelemetryService
# pyrefly: ignore [missing-import]
from app.config import settings


@pytest.mark.asyncio
async def test_telemetry_retry_limit_exhaustion():
    """
    Verifica que el servicio intente exactamente MAX_SENSOR_RETRIES (3) veces y no falle silenciosamente.
    """
    service = TelemetryService()
    # Ajustar timeout y reintentos para test rápido
    settings.MAX_SENSOR_RETRIES = 3

    with respx.mock(base_url=f"http://{settings.ESP32_IP}:{settings.ESP32_PORT}") as respx_mock:
        route = respx_mock.get("/api/v1/telemetry").mock(
            side_effect=httpx.ConnectError("Simulated network timeout")
        )

        result = await service.fetch_telemetry_with_retry()

        assert result is None
        assert route.call_count == 3  # Exactamente 3 intentos según las reglas del workspace
