"""
Pruebas del Motor Logístico InvAgent y Razonamiento Chain-of-Thought (CoT).
"""

# pyrefly: ignore [missing-import]
from app.logistics.inv_agent import InvAgent


def test_invagent_golden_rule_open_orders():
    """
    Verifica la aplicación estricta de la Regla de Oro:
    Órdenes Abiertas = Demanda Esperada + Backlog
    """
    agent = InvAgent(max_capacity=500)
    expected_demand = 35
    backlog = 15

    decision = agent.decide(
        current_stock=20,  # Debajo del punto de reorden
        backlog=backlog,
        reorder_point=40,
        expected_demand=expected_demand,
        lead_time_days=3,
        safety_stock=10
    )

    # Verificación de la Regla de Oro
    assert decision.open_orders == (expected_demand + backlog)
    assert decision.open_orders == 50
    assert decision.reorder_triggered is True


def test_invagent_chain_of_thought_format():
    """
    Verifica que el razonamiento Chain-of-Thought (CoT) contenga exactamente 1-2 oraciones.
    """
    agent = InvAgent()
    decision = agent.decide(
        current_stock=15,
        backlog=10,
        reorder_point=25,
        expected_demand=20,
        lead_time_days=2,
        safety_stock=8
    )

    cot_text = decision.reasoning_cot.strip()
    assert len(cot_text) > 20

    # Contar oraciones delimitadas por puntos
    sentences = [s.strip() for s in cot_text.split(".") if s.strip()]
    assert 1 <= len(sentences) <= 2, f"Se esperaban 1 o 2 oraciones, pero se obtuvieron {len(sentences)}: {cot_text}"


def test_invagent_bullwhip_capacity_mitigation():
    """
    Verifica que los pedidos no superen la capacidad máxima de producción para evitar el efecto látigo.
    """
    max_cap = 100
    agent = InvAgent(max_capacity=max_cap)

    # Demanda y backlog inmensos que exigirían 300 unidades
    decision = agent.decide(
        current_stock=5,
        backlog=150,
        reorder_point=50,
        expected_demand=150,
        lead_time_days=4,
        safety_stock=20
    )

    assert decision.open_orders == 300
    assert decision.recommended_order_qty == max_cap  # Acotado al límite de producción para suavizar varianza


def test_invagent_no_reorder_when_stock_healthy():
    """
    Verifica que no se dispare reorden cuando el stock está sano y sin backlog.
    """
    agent = InvAgent()
    decision = agent.decide(
        current_stock=120,
        backlog=0,
        reorder_point=30,
        expected_demand=15,
        lead_time_days=3,
        safety_stock=10
    )

    assert decision.reorder_triggered is False
    assert decision.recommended_order_qty == 0
