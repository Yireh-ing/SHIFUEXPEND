"""
Configuración de Pines y Parámetros para Raspberry Pi Pico (MicroPython).
"""

# Identificador del dispositivo
DEVICE_ID = "PICO-EDGE-01"

# Asignación de Pines GPIO
PIN_IR_SENSOR = 15      # GP15: Entrada digital del sensor IR (0 = Detectado, 1 = Libre)
PIN_STATUS_LED = 14     # GP14: Salida digital para LED indicador de presencia/estado
PIN_ONBOARD_LED = 25    # GP25: LED onboard de la Pico (pulso de latido/heartbeat)

# Parámetros de Muestreo y Anti-rebote (Debounce)
DEBOUNCE_MS = 80        # Ventana de estabilización en milisegundos para evitar falsos positivos
SAMPLING_INTERVAL_MS = 50 # Intervalo del ciclo de sondeo en milisegundos

# Umbrales Iniciales de Inventario Local
INITIAL_STOCK = 150
REORDER_POINT = 30
EXPECTED_DEMAND = 25
BACKLOG = 0
LEAD_TIME_DAYS = 3
