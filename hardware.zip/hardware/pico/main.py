"""
Firmware MicroPython para Raspberry Pi Pico - Captura de Telemetría Infrarroja (IR).
Módulo de Edge Hardware para Sistema Logístico Autónomo.
"""

# pyrefly: ignore [missing-import]
import machine
import time
# pyrefly: ignore [missing-import]
import ujson
from config import (
    DEVICE_ID,
    PIN_IR_SENSOR,
    PIN_STATUS_LED,
    PIN_ONBOARD_LED,
    DEBOUNCE_MS,
    SAMPLING_INTERVAL_MS,
    INITIAL_STOCK,
    REORDER_POINT,
    EXPECTED_DEMAND,
    BACKLOG,
    LEAD_TIME_DAYS
)

# Inicialización de hardware
# Pin GP15 con resistencia Pull-Up interna activada (el sensor IR envía LOW / 0 al detectar)
ir_pin = machine.Pin(PIN_IR_SENSOR, machine.Pin.IN, machine.Pin.PULL_UP)
led_status = machine.Pin(PIN_STATUS_LED, machine.Pin.OUT)

try:
    led_heartbeat = machine.Pin(PIN_ONBOARD_LED, machine.Pin.OUT)
except Exception:
    # Para variantes Pico W donde el onboard LED se mapea distinto
    led_heartbeat = None

# Variables de estado
item_count = 0
last_sensor_state = 1  # 1 = Ausencia inicial
last_debounce_time = 0
current_stock = INITIAL_STOCK

def get_iso_timestamp():
    """Genera una marca de tiempo en formato ISO-8601 usando RTC de MicroPython."""
    try:
        t = time.localtime()
        # Formato: YYYY-MM-DDTHH:MM:SSZ
        return "{:04d}-{:02d}-{:02d}T{:02d}:{:02d}:{:02d}Z".format(
            t[0], t[1], t[2], t[3], t[4], t[5]
        )
    except Exception:
        return "1970-01-01T00:00:00Z"

def build_telemetry_payload(ir_val: int, count: int, stock: int) -> dict:
    """Construye el payload de telemetría cumpliendo con schema.json."""
    return {
        "device_id": DEVICE_ID,
        "timestamp": get_iso_timestamp(),
        "sensor_data": {
            "ir_status": ir_val,
            "item_count": count,
            "sampling_rate_ms": SAMPLING_INTERVAL_MS
        },
        "inventory_state": {
            "current_stock": max(0, stock),
            "backlog": BACKLOG,
            "reorder_point": REORDER_POINT,
            "expected_demand": EXPECTED_DEMAND,
            "lead_time_days": LEAD_TIME_DAYS
        }
    }

def main():
    global item_count, last_sensor_state, last_debounce_time, current_stock
    
    print("[EDGE PICO] Inicializando sistema de conteo IR en GP15 y LED en GP14...")
    led_status.value(0)
    
    # Secuencia de arranque del LED (3 pulsos)
    for _ in range(3):
        led_status.value(1)
        time.sleep_ms(100)
        led_status.value(0)
        time.sleep_ms(100)

    print(f"[EDGE PICO] Dispositivo {DEVICE_ID} operativo. Monitoreando objetos...")
    
    heartbeat_counter = 0

    while True:
        try:
            # Lectura del sensor: 0 = Objeto detectado, 1 = Ausencia
            raw_reading = ir_pin.value()
            current_time = time.ticks_ms()

            # Detección de flanco de bajada (transición de ausencia 1 a presencia 0) con anti-rebote
            if raw_reading == 0 and last_sensor_state == 1:
                if time.ticks_diff(current_time, last_debounce_time) > DEBOUNCE_MS:
                    item_count += 1
                    # En una línea de despacho, cada paso reduce stock físico
                    if current_stock > 0:
                        current_stock -= 1
                        
                    last_debounce_time = current_time
                    led_status.value(1) # Encender LED de confirmación
                    
                    payload = build_telemetry_payload(raw_reading, item_count, current_stock)
                    print("[TELEMETRIA_EVENT]", ujson.dumps(payload))
            
            elif raw_reading == 1 and last_sensor_state == 0:
                # Transición de vuelta a ausencia
                if time.ticks_diff(current_time, last_debounce_time) > (DEBOUNCE_MS // 2):
                    led_status.value(0) # Apagar LED cuando el objeto sale
            
            last_sensor_state = raw_reading

            # Heartbeat periódico cada 2 segundos (~40 iteraciones de 50ms)
            heartbeat_counter += 1
            if heartbeat_counter >= 40:
                heartbeat_counter = 0
                if led_heartbeat:
                    led_heartbeat.toggle()
                # Reporte de estado periódico
                periodic_payload = build_telemetry_payload(raw_reading, item_count, current_stock)
                print("[TELEMETRIA_HEARTBEAT]", ujson.dumps(periodic_payload))

            time.sleep_ms(SAMPLING_INTERVAL_MS)

        except KeyboardInterrupt:
            print("[EDGE PICO] Detención manual solicitada.")
            led_status.value(0)
            break
        except Exception as e:
            # Manejo de error explícito para evitar parada de firmware
            print(f"[EDGE PICO ERROR] Excepción no controlada en loop: {e}")
            time.sleep_ms(500)

if __name__ == "__main__":
    main()
