/**
 * @file main.ino
 * @brief Firmware Principal C++ Asíncrono para ESP32 - Gateway de Telemetría IoT.
 * @author Lead de IA Multi-Agente & Software Architect
 */

#include <Arduino.h>
#include <WiFi.h>
#include "ESP32_Utils_APIREST.hpp"
#include "Server.hpp"

// Configuración de Red WiFi
// NOTA DE SEGURIDAD: En despliegue real se configuran mediante variables en compilation-time
// o a través de un portal cautivo WiFiManager.
#ifndef WIFI_SSID
#define WIFI_SSID "LOGISTICS_SECURE_WIFI"
#endif

#ifndef WIFI_PASS
#define WIFI_PASS "IOT_SECURE_TOKEN_2026"
#endif

// Instancias globales
TelemetryModel currentTelemetry;
unsigned long bootTimeMs = 0;
Server restServer(80);

// Pin del sensor IR en caso de conexión directa al ESP32 (GPIO 4)
const int PIN_IR_DIRECT = 4;
const int PIN_STATUS_LED = 2; // LED Onboard (GPIO 2)

// Tarea periódica para actualizar timestamps y telemetría de red
unsigned long lastHeartbeatTime = 0;
const unsigned long HEARTBEAT_INTERVAL_MS = 5000;

void setupWiFi() {
    Serial.println("\n[WIFI] Conectando a la red...");
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(250);
        Serial.print(".");
        attempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\n[WIFI] Conexión establecida.");
        Serial.print("[WIFI] Dirección IP Asignada: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("\n[WIFI] No se pudo conectar a la red principal. Iniciando modo Access Point de respaldo...");
        WiFi.mode(WIFI_AP);
        WiFi.softAP("ESP32-LOGISTICS-FALLBACK", "logistics1234");
        Serial.print("[WIFI] IP de Punto de Acceso: ");
        Serial.println(WiFi.softAPIP());
    }
}

void setup() {
    Serial.begin(115200);
    bootTimeMs = millis();
    delay(500);

    Serial.println("=================================================");
    Serial.println("   SISTEMA LOGISTICO IOT - GATEWAY ESP32 V1.0    ");
    Serial.println("=================================================");

    pinMode(PIN_IR_DIRECT, INPUT_PULLUP);
    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_STATUS_LED, LOW);

    // Inicializar modelo de telemetría por defecto
    currentTelemetry.device_id = "ESP32-GATEWAY-ZONE-A";
    currentTelemetry.timestamp = "2026-09-25T12:00:00Z";
    currentTelemetry.sensor.ir_status = 1;
    currentTelemetry.sensor.item_count = 0;
    currentTelemetry.sensor.sampling_rate_ms = 100;
    currentTelemetry.inventory.current_stock = 85;
    currentTelemetry.inventory.backlog = 5;
    currentTelemetry.inventory.reorder_point = 30;
    currentTelemetry.inventory.expected_demand = 25;
    currentTelemetry.inventory.lead_time_days = 3;
    currentTelemetry.inventory.safety_stock = 10;

    setupWiFi();

    // Arrancar servidor REST Asíncrono
    restServer.setupRoutes();
    restServer.begin();

    // Indicador visual de encendido
    digitalWrite(PIN_STATUS_LED, HIGH);
    Serial.println("[SETUP] ESP32 Gateway inicializado y listo para recibir peticiones.");
}

void loop() {
    // Arquitectura asíncrona: El loop permanece liviano y sin delays bloqueantes.
    unsigned long currentMillis = millis();

    // Monitoreo no bloqueante del sensor físico directo
    int irVal = digitalRead(PIN_IR_DIRECT);
    if (irVal != currentTelemetry.sensor.ir_status) {
        currentTelemetry.sensor.ir_status = irVal;
        if (irVal == 0) { // Objeto detectado
            currentTelemetry.sensor.item_count++;
            if (currentTelemetry.inventory.current_stock > 0) {
                currentTelemetry.inventory.current_stock--;
            }
            digitalWrite(PIN_STATUS_LED, HIGH);
        } else {
            digitalWrite(PIN_STATUS_LED, LOW);
        }
    }

    // Tarea de mantenimiento periódico
    if (currentMillis - lastHeartbeatTime >= HEARTBEAT_INTERVAL_MS) {
        lastHeartbeatTime = currentMillis;
        currentTelemetry.sensor.rssi_dbm = WiFi.RSSI();
        // Generar timestamp dinámico simple de uptime
        unsigned long uptimeSec = (currentMillis - bootTimeMs) / 1000;
        char timeBuf[32];
        snprintf(timeBuf, sizeof(timeBuf), "UPTIME-%lums", uptimeSec);
        currentTelemetry.timestamp = String(timeBuf);
    }

    // Pequeño rendimiento de tiempo (yield) para el planificador de FreeRTOS
    vTaskDelay(pdMS_TO_TICKS(10));
}
