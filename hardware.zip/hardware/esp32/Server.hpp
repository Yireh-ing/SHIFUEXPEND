#pragma once

#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include "API.hpp"

/**
 * @file Server.hpp
 * @brief Configuración, middlewares y montaje de rutas para el servidor asíncrono ESPAsyncWebServer.
 */

class Server {
private:
    AsyncWebServer server;

public:
    Server(uint16_t port = 80) : server(port) {}

    void setupRoutes() {
        // Middleware de CORS para permitir consumo desde frontends web y clientes API
        DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");
        DefaultHeaders::Instance().addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        DefaultHeaders::Instance().addHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        // Manejador para pre-flight OPTIONS
        server.onNotFound([](AsyncWebServerRequest *request) {
            if (request->method() == HTTP_OPTIONS) {
                request->send(200);
            } else {
                request->send(404, "application/json", ESP32_Utils_APIREST::buildErrorResponse(404, "Ruta no encontrada en el gateway IoT"));
            }
        });

        // 1. GET /api/v1/telemetry
        server.on("/api/v1/telemetry", HTTP_GET, API::handleGetTelemetry);

        // 2. POST /api/v1/telemetry
        server.on("/api/v1/telemetry", HTTP_POST, 
            [](AsyncWebServerRequest *request) {}, 
            NULL, 
            API::handlePostTelemetry
        );

        // 3. PUT /api/v1/inventory
        server.on("/api/v1/inventory", HTTP_PUT, 
            [](AsyncWebServerRequest *request) {}, 
            NULL, 
            API::handlePutInventory
        );

        // 4. DELETE /api/v1/inventory/reset
        server.on("/api/v1/inventory/reset", HTTP_DELETE, API::handleDeleteReset);

        // 5. GET /api/v1/status
        server.on("/api/v1/status", HTTP_GET, API::handleGetStatus);

        Serial.println("[SERVER] Rutas de la API REST registradas exitosamente.");
    }

    void begin() {
        server.begin();
        Serial.println("[SERVER] ESPAsyncWebServer iniciado en el puerto 80.");
    }
};
