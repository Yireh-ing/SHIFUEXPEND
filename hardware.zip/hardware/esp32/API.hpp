#pragma once

#include <ESPAsyncWebServer.h>
#include "ESP32_Utils_APIREST.hpp"

/**
 * @file API.hpp
 * @brief Implementación de endpoints REST (GET, POST, PUT, DELETE) para telemetría e inventario.
 */

// Estado global en memoria para el gateway IoT
extern TelemetryModel currentTelemetry;
extern unsigned long bootTimeMs;

class API {
public:
    /**
     * GET /api/v1/telemetry
     * Retorna el estado actual de telemetría y sensores en formato JSON conforme a schema.json
     */
    static void handleGetTelemetry(AsyncWebServerRequest *request) {
        currentTelemetry.sensor.rssi_dbm = WiFi.RSSI();
        String payload = ESP32_Utils_APIREST::serializeTelemetry(currentTelemetry);
        request->send(200, "application/json", payload);
    }

    /**
     * POST /api/v1/telemetry
     * Actualiza la telemetría del sensor y estado desde fuentes externas o Edge Pico
     */
    static void handlePostTelemetry(AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
        String body = String((char*)data).substring(0, len);
        String errorMsg;

        if (!ESP32_Utils_APIREST::deserializeTelemetry(body, currentTelemetry, errorMsg)) {
            request->send(400, "application/json", ESP32_Utils_APIREST::buildErrorResponse(400, errorMsg));
            return;
        }

        String response = ESP32_Utils_APIREST::buildSuccessResponse("Telemetría actualizada correctamente");
        request->send(201, "application/json", response);
    }

    /**
     * PUT /api/v1/inventory
     * Actualiza parámetros del inventario (reorder_point, current_stock, backlog, expected_demand)
     */
    static void handlePutInventory(AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
        String body = String((char*)data).substring(0, len);
        StaticJsonDocument<512> doc;
        DeserializationError err = deserializeJson(doc, body);

        if (err) {
            request->send(400, "application/json", ESP32_Utils_APIREST::buildErrorResponse(400, "JSON inválido en PUT"));
            return;
        }

        if (doc.containsKey("current_stock")) {
            currentTelemetry.inventory.current_stock = doc["current_stock"].as<int>();
        }
        if (doc.containsKey("reorder_point")) {
            currentTelemetry.inventory.reorder_point = doc["reorder_point"].as<int>();
        }
        if (doc.containsKey("backlog")) {
            currentTelemetry.inventory.backlog = doc["backlog"].as<int>();
        }
        if (doc.containsKey("expected_demand")) {
            currentTelemetry.inventory.expected_demand = doc["expected_demand"].as<int>();
        }
        if (doc.containsKey("lead_time_days")) {
            currentTelemetry.inventory.lead_time_days = doc["lead_time_days"].as<int>();
        }

        String response = ESP32_Utils_APIREST::buildSuccessResponse("Estado de inventario actualizado exitosamente");
        request->send(200, "application/json", response);
    }

    /**
     * DELETE /api/v1/inventory/reset
     * Reinicia los contadores del sensor y el backlog a valores limpios iniciales
     */
    static void handleDeleteReset(AsyncWebServerRequest *request) {
        currentTelemetry.sensor.item_count = 0;
        currentTelemetry.inventory.backlog = 0;
        
        String response = ESP32_Utils_APIREST::buildSuccessResponse("Contadores y backlog reiniciados a cero.");
        request->send(200, "application/json", response);
    }

    /**
     * GET /api/v1/status
     * Estado del microcontrolador: uptime, heap disponible, estado WiFi
     */
    static void handleGetStatus(AsyncWebServerRequest *request) {
        StaticJsonDocument<256> doc;
        doc["status"] = "online";
        doc["uptime_seconds"] = (millis() - bootTimeMs) / 1000;
        doc["free_heap_bytes"] = ESP.getFreeHeap();
        doc["wifi_rssi_dbm"] = WiFi.RSSI();
        doc["ip_address"] = WiFi.localIP().toString();

        String payload;
        serializeJson(doc, payload);
        request->send(200, "application/json", payload);
    }
};
