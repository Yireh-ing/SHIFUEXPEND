#pragma once

#if defined(ARDUINO) || (defined(__has_include) && __has_include(<Arduino.h>))
#include <Arduino.h>
#include <ArduinoJson.h>
#else
// Declaraciones de compatibilidad para análisis estático en IDEs sin toolchain de Arduino
#include <string>
#include <sstream>
#include <memory>
#include <cstdint>
#include <cstring>

class String : public std::string {
public:
    using std::string::string;
    String() = default;
    String(const std::string& s) : std::string(s) {}
    String(const char* s) : std::string(s ? s : "") {}
    String(int val) : std::string(std::to_string(val)) {}
    String(long val) : std::string(std::to_string(val)) {}
    String(unsigned long val) : std::string(std::to_string(val)) {}
    String(double val) : std::string(std::to_string(val)) {}
    String substring(size_t from, size_t to) const {
        return (from < length()) ? substr(from, (to > from) ? (to - from) : 0) : "";
    }
    const char* c_str() const { return std::string::c_str(); }
};

inline String operator+(const String& lhs, const char* rhs) {
    return String(static_cast<const std::string&>(lhs) + (rhs ? rhs : ""));
}
inline String operator+(const char* lhs, const String& rhs) {
    return String((lhs ? lhs : "") + static_cast<const std::string&>(rhs));
}

struct DeserializationError {
    enum Code { Ok, EmptyInput, IncompleteInput, InvalidInput, NoMemory, NotSupported, TooDeep };
    Code code = Ok;
    operator bool() const { return code != Ok; }
    const char* c_str() const { return "error"; }
};

class JsonVariant;
class JsonObject;

class JsonVariant {
public:
    template<typename T> T as() const { return T(); }
    bool containsKey(const char*) const { return true; }
    JsonVariant operator[](const char*) const { return *this; }
    JsonVariant& operator=(const JsonVariant&) { return *this; }
    template<typename T> JsonVariant& operator=(const T&) { return *this; }
};

class JsonObject : public JsonVariant {};

class JsonDocument : public JsonVariant {
public:
    JsonObject createNestedObject(const char*) { return JsonObject(); }
};

template<size_t CAPACITY>
class StaticJsonDocument : public JsonDocument {};

inline DeserializationError deserializeJson(JsonDocument&, const String&) { return DeserializationError(); }
inline void serializeJson(const JsonDocument&, String&) {}
#endif

/**
 * @file ESP32_Utils_APIREST.hpp
 * @brief Utilidades para serialización, deserialización y validación del contrato schema.json en ESP32.
 */

struct SensorData {
    int ir_status = 1;        // 0: Detectado, 1: Ausencia
    int item_count = 0;       // Conteo acumulado
    int sampling_rate_ms = 100;
    float rssi_dbm = 0.0f;
};

struct InventoryState {
    int current_stock = 100;
    int backlog = 0;
    int reorder_point = 25;
    int expected_demand = 20;
    int lead_time_days = 3;
    int safety_stock = 10;
};

struct TelemetryModel {
    String device_id = "ESP32-LOGISTICS-GATEWAY-01";
    String timestamp = "2026-09-25T12:00:00Z";
    SensorData sensor;
    InventoryState inventory;
};

class ESP32_Utils_APIREST {
public:
    /**
     * Serializa el modelo de telemetría a formato JSON cumpliendo estrictamente con schema.json
     */
    static String serializeTelemetry(const TelemetryModel& model) {
        StaticJsonDocument<768> doc;
        
        doc["device_id"] = model.device_id;
        doc["timestamp"] = model.timestamp;
        
        JsonObject sensorObj = doc.createNestedObject("sensor_data");
        sensorObj["ir_status"] = model.sensor.ir_status;
        sensorObj["item_count"] = model.sensor.item_count;
        sensorObj["sampling_rate_ms"] = model.sensor.sampling_rate_ms;
        sensorObj["rssi_dbm"] = model.sensor.rssi_dbm;

        JsonObject invObj = doc.createNestedObject("inventory_state");
        invObj["current_stock"] = model.inventory.current_stock;
        invObj["backlog"] = model.inventory.backlog;
        invObj["reorder_point"] = model.inventory.reorder_point;
        invObj["expected_demand"] = model.inventory.expected_demand;
        invObj["lead_time_days"] = model.inventory.lead_time_days;
        invObj["safety_stock"] = model.inventory.safety_stock;

        String output;
        serializeJson(doc, output);
        return output;
    }

    /**
     * Deserializa y valida un payload JSON entrante contra los campos obligatorios del contrato
     */
    static bool deserializeTelemetry(const String& jsonPayload, TelemetryModel& outModel, String& outError) {
        StaticJsonDocument<1024> doc;
        DeserializationError err = deserializeJson(doc, jsonPayload);

        if (err) {
            outError = String("Error de parsing JSON: ") + err.c_str();
            return false;
        }

        // Validación de campos raíz requeridos
        if (!doc.containsKey("device_id") || !doc.containsKey("sensor_data") || !doc.containsKey("inventory_state")) {
            outError = "Faltan campos obligatorios en el contrato raíz (device_id, sensor_data, inventory_state)";
            return false;
        }

        JsonObject sensor = doc["sensor_data"];
        if (!sensor.containsKey("ir_status") || !sensor.containsKey("item_count")) {
            outError = "sensor_data debe incluir 'ir_status' e 'item_count'";
            return false;
        }

        JsonObject inv = doc["inventory_state"];
        if (!inv.containsKey("current_stock") || !inv.containsKey("backlog") ||
            !inv.containsKey("reorder_point") || !inv.containsKey("expected_demand")) {
            outError = "inventory_state debe incluir 'current_stock', 'backlog', 'reorder_point', 'expected_demand'";
            return false;
        }

        // Mapeo seguro a la estructura interna
        outModel.device_id = doc["device_id"].as<String>();
        if (doc.containsKey("timestamp")) {
            outModel.timestamp = doc["timestamp"].as<String>();
        }

        outModel.sensor.ir_status = sensor["ir_status"].as<int>();
        outModel.sensor.item_count = sensor["item_count"].as<int>();
        if (sensor.containsKey("sampling_rate_ms")) {
            outModel.sensor.sampling_rate_ms = sensor["sampling_rate_ms"].as<int>();
        }

        outModel.inventory.current_stock = inv["current_stock"].as<int>();
        outModel.inventory.backlog = inv["backlog"].as<int>();
        outModel.inventory.reorder_point = inv["reorder_point"].as<int>();
        outModel.inventory.expected_demand = inv["expected_demand"].as<int>();
        if (inv.containsKey("lead_time_days")) {
            outModel.inventory.lead_time_days = inv["lead_time_days"].as<int>();
        }
        if (inv.containsKey("safety_stock")) {
            outModel.inventory.safety_stock = inv["safety_stock"].as<int>();
        }

        return true;
    }

    /**
     * Construye un JSON estándar para respuestas de error
     */
    static String buildErrorResponse(int code, const String& message) {
        StaticJsonDocument<256> doc;
        doc["status"] = "error";
        doc["code"] = code;
        doc["message"] = message;
        String res;
        serializeJson(doc, res);
        return res;
    }

    /**
     * Construye un JSON estándar para respuestas exitosas
     */
    static String buildSuccessResponse(const String& message, const JsonDocument* extra = nullptr) {
        StaticJsonDocument<512> doc;
        doc["status"] = "success";
        doc["message"] = message;
        if (extra != nullptr) {
            doc["data"] = *extra;
        }
        String res;
        serializeJson(doc, res);
        return res;
    }
};
